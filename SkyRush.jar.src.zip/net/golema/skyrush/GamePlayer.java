/*     */ package net.golema.skyrush;
/*     */ 
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import net.golema.api.games.GameLobbyTask;
/*     */ import net.golema.api.games.GamePlayerAbstract;
/*     */ import net.golema.api.games.kits.KitAbstract;
/*     */ import net.golema.api.games.servers.LoadashAPI;
/*     */ import net.golema.api.games.teams.Teams;
/*     */ import net.golema.api.players.GolemaPlayer;
/*     */ import net.golema.api.players.stats.games.SkyRushStats;
/*     */ import net.golema.api.utils.GolemaAPI;
/*     */ import net.golema.api.utils.builders.items.ItemFactory;
/*     */ import net.golema.api.utils.builders.scoreboards.ScoreboardSign;
/*     */ import net.golema.api.utils.builders.titles.ActionBarBuilder;
/*     */ import net.md_5.bungee.api.ChatColor;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.GameMode;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ 
/*     */ 
/*     */ public class GamePlayer
/*     */   extends GamePlayerAbstract
/*     */ {
/*  29 */   private static Map<Player, GamePlayer> gamePlayers = new HashMap<>();
/*     */   
/*     */   private Player player;
/*     */   
/*     */   private GolemaPlayer golemaPlayer;
/*     */   private SkyRushStats skyRushStats;
/*  35 */   private int tokens = 0;
/*  36 */   private int changeKit = 0;
/*     */ 
/*     */ 
/*     */   
/*     */   public ScoreboardSign scoreboardSign;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GamePlayer(Player player) {
/*  46 */     this.player = player;
/*  47 */     this.golemaPlayer = GolemaPlayer.get(player.getUniqueId());
/*     */ 
/*     */     
/*  50 */     this.scoreboardSign = new ScoreboardSign(player, player.getName());
/*  51 */     this.scoreboardSign
/*  52 */       .setObjectiveName(ChatColor.GOLD + "" + ChatColor.BOLD + GolemaAPI.getGameSetting().getGameName());
/*  53 */     this.scoreboardSign.create();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SkyRushStats getPlayerStats() {
/*  62 */     if (this.skyRushStats == null)
/*  63 */       this.skyRushStats = SkyRushStats.get(this.player.getUniqueId()); 
/*  64 */     return this.skyRushStats;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void loadScoreboard() {
/*  71 */     this.scoreboardSign.setLine(11, "§d");
/*  72 */     this.scoreboardSign.setLine(10, ChatColor.WHITE + "Joueurs : " + ChatColor.YELLOW + Bukkit.getOnlinePlayers().size() + ChatColor.GRAY + "/" + ChatColor.WHITE + 
/*  73 */         Bukkit.getMaxPlayers());
/*  74 */     this.scoreboardSign.setLine(9, "§c");
/*  75 */     this.scoreboardSign.setLine(8, ChatColor.RED + "En attente de");
/*  76 */     this.scoreboardSign.setLine(7, ChatColor.RED + "joueurs...");
/*  77 */     this.scoreboardSign.setLine(6, "§b");
/*  78 */     this.scoreboardSign.setLine(5, ChatColor.WHITE + "Lancement : " + ChatColor.GREEN + (new SimpleDateFormat("mm:ss"))
/*  79 */         .format(new Date((GameLobbyTask.lobbyTimer.intValue() * 1000))));
/*  80 */     this.scoreboardSign.setLine(4, "§b");
/*  81 */     this.scoreboardSign.setLine(3, ChatColor.WHITE + "Kit : " + ChatColor.RED + "Aucun");
/*  82 */     this.scoreboardSign.setLine(2, ChatColor.WHITE + "Carte : " + ChatColor.AQUA + 
/*  83 */         LoadashAPI.getGolemaServer().getMapInfos().getName());
/*  84 */     this.scoreboardSign.setLine(1, "§1");
/*  85 */     this.scoreboardSign.setLine(0, ChatColor.GOLD + "play.golemamc.net");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void loadGameScoreboard() {
/*  92 */     this.scoreboardSign.setObjectiveName(ChatColor.GOLD + "" + ChatColor.BOLD + GolemaAPI.getGameSetting().getGameName() + ChatColor.WHITE + "│ " + ChatColor.GRAY + "00:00");
/*     */     
/*  94 */     this.scoreboardSign.setLine(13, "");
/*  95 */     this.scoreboardSign.setLine(12, ChatColor.WHITE + "Equipe : " + (isSpectator() ? (ChatColor.GRAY + "Spectateur") : (
/*  96 */         getTeam().getChatColor() + getTeam().getName())));
/*  97 */     this.scoreboardSign.setLine(11, ChatColor.WHITE + "Tués : " + ChatColor.GREEN + getKills());
/*  98 */     this.scoreboardSign.setLine(10, ChatColor.WHITE + "Mort : " + ChatColor.RED + getDeaths());
/*  99 */     this.scoreboardSign.setLine(9, "");
/* 100 */     this.scoreboardSign.setLine(8, ChatColor.WHITE + "Tokens : " + ChatColor.YELLOW + "" + ChatColor.BOLD + 
/* 101 */         getTokens() + " ✸");
/* 102 */     this.scoreboardSign.setLine(7, "");
/* 103 */     this.scoreboardSign.setLine(6, Teams.RED
/* 104 */         .getChatColor() + "■ " + ChatColor.GRAY + "Golem : " + ChatColor.GRAY + "init...");
/* 105 */     this.scoreboardSign.setLine(5, Teams.BLUE
/* 106 */         .getChatColor() + "■ " + ChatColor.GRAY + "Golem : " + ChatColor.GRAY + "init...");
/*     */ 
/*     */     
/* 109 */     if (isSpectator()) {
/* 110 */       this.scoreboardSign.setLine(4, "§b");
/* 111 */       this.scoreboardSign.setLine(3, ChatColor.WHITE + "Kit : " + ChatColor.RED + "Aucun");
/* 112 */       this.scoreboardSign.setLine(2, ChatColor.WHITE + "Carte : " + ChatColor.AQUA + 
/* 113 */           LoadashAPI.getGolemaServer().getMapInfos().getName());
/* 114 */       this.scoreboardSign.setLine(1, "§1");
/* 115 */       this.scoreboardSign.setLine(0, ChatColor.GOLD + "play.golemamc.net");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Player getTrackerTargetPlayer(double maxDistance) {
/* 126 */     Player closest = null;
/* 127 */     double distance = maxDistance;
/* 128 */     for (Player target : this.player.getWorld().getPlayers()) {
/* 129 */       if (!getPlayer(target).isSpectator() && target != this.player && 
/* 130 */         getPlayer(target).getTeam() != null && 
/* 131 */         !getPlayer(target).getTeam().equals(getTeam())) {
/* 132 */         double distante = target.getLocation().distanceSquared(this.player.getLocation());
/* 133 */         if (distante < distance) {
/* 134 */           closest = target;
/* 135 */           distance = distante;
/*     */         } 
/*     */       } 
/*     */     } 
/* 139 */     return closest;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void makeTrade(int price, ItemStack itemStack, String name) {
/* 150 */     String prefix = ChatColor.LIGHT_PURPLE + "" + ChatColor.BOLD + "Shop" + ChatColor.GRAY + " » ";
/*     */ 
/*     */     
/* 153 */     if (getTokens() < price) {
/* 154 */       this.player.sendMessage(prefix + ChatColor.RED + "Vous n'avez pas assez de Tokens.");
/* 155 */       this.player.closeInventory();
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 160 */     if (isInventoryFull()) {
/* 161 */       this.player.sendMessage(prefix + ChatColor.RED + "Attention, votre inventaire est plein.");
/* 162 */       this.player.closeInventory();
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 167 */     this.tokens -= price;
/* 168 */     if (itemStack.getType().equals(Material.CHAINMAIL_HELMET)) {
/* 169 */       this.player.getInventory().setHelmet(itemStack);
/* 170 */     } else if (itemStack.getType().equals(Material.IRON_CHESTPLATE)) {
/* 171 */       this.player.getInventory().setChestplate(itemStack);
/* 172 */     } else if (itemStack.getType().equals(Material.CHAINMAIL_LEGGINGS)) {
/* 173 */       this.player.getInventory().setLeggings(itemStack);
/* 174 */     } else if (itemStack.getType().equals(Material.IRON_BOOTS)) {
/* 175 */       this.player.getInventory().setBoots(itemStack);
/*     */     } else {
/* 177 */       this.player.getInventory().addItem(new ItemStack[] { itemStack });
/* 178 */     }  this.player.sendMessage(prefix + ChatColor.WHITE + "Validation de votre achat : " + ChatColor.YELLOW + name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isInventoryFull() {
/* 186 */     return (this.player.getInventory().firstEmpty() == -1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void sendStuff() {
/* 193 */     if (getTeam() != null) {
/* 194 */       this.player.getInventory().clear();
/* 195 */       this.player.getInventory()
/* 196 */         .setHelmet(ItemFactory.buildLeatherColorArmor(Material.LEATHER_HELMET, getTeam().getColor()));
/* 197 */       this.player.getInventory().setChestplate(
/* 198 */           ItemFactory.buildLeatherColorArmor(Material.LEATHER_CHESTPLATE, getTeam().getColor()));
/* 199 */       this.player.getInventory()
/* 200 */         .setLeggings(ItemFactory.buildLeatherColorArmor(Material.LEATHER_LEGGINGS, getTeam().getColor()));
/* 201 */       this.player.getInventory()
/* 202 */         .setBoots(ItemFactory.buildLeatherColorArmor(Material.LEATHER_BOOTS, getTeam().getColor()));
/* 203 */       this.player.getInventory().setItem(8, (new ItemFactory(Material.COMPASS))
/* 204 */           .withName(ChatColor.GOLD + "■" + ChatColor.YELLOW + " Tracker de joueurs " + ChatColor.GOLD + "■")
/*     */           
/* 206 */           .done());
/* 207 */       if (getKit() == null) {
/* 208 */         this.player.getInventory().addItem(new ItemStack[] { (new ItemFactory(Material.STONE_SWORD)).done() });
/* 209 */         this.player.getInventory().addItem(new ItemStack[] { (new ItemFactory(Material.IRON_PICKAXE)).done() });
/* 210 */         this.player.getInventory().addItem(new ItemStack[] { (new ItemFactory(new ItemStack(Material.STAINED_CLAY, 1, 
/* 211 */                   getTeam().equals(Teams.RED) ? 14 : 3)))
/* 212 */               .withAmount(96).done() });
/* 213 */         this.player.getInventory().addItem(new ItemStack[] { (new ItemFactory(Material.COOKED_MUTTON)).withAmount(8).done() });
/*     */       } else {
/* 215 */         getKit().sendKit(this.player);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public GolemaPlayer getGolemaPlayer() {
/* 221 */     return this.golemaPlayer;
/*     */   }
/*     */ 
/*     */   
/*     */   public KitAbstract getKit() {
/* 226 */     return GolemaAPI.getGameSetting().getKitManager().getPlayerKit(this.player.getUniqueId());
/*     */   }
/*     */ 
/*     */   
/*     */   public ScoreboardSign getScoreboard() {
/* 231 */     return this.scoreboardSign;
/*     */   }
/*     */ 
/*     */   
/*     */   public Teams getTeam() {
/* 236 */     return GolemaAPI.getGameSetting().getTeamManager().getPlayerTeam(this.player);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getTimePlayed() {
/* 241 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSpectator() {
/* 246 */     return this.golemaPlayer.isSpectator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTokens() {
/* 253 */     return this.tokens;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addTokens(int tokens, boolean display) {
/* 262 */     this.tokens += tokens;
/* 263 */     if (display) {
/* 264 */       (new ActionBarBuilder(ChatColor.GRAY + "+" + ChatColor.YELLOW + "" + ChatColor.BOLD + tokens + " Tokens ✸"))
/* 265 */         .sendTo(this.player);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getChangeKit() {
/* 272 */     return this.changeKit;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addKitChange() {
/* 279 */     this.changeKit++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canChangeKit() {
/* 286 */     return (this.changeKit < 3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSpectator() {
/* 295 */     this.golemaPlayer.setSpectator(true);
/* 296 */     GolemaAPI.getGameSetting().getTeamManager().setSpectator(this.player);
/* 297 */     this.player.setGameMode(GameMode.SPECTATOR);
/*     */ 
/*     */     
/* 300 */     SkyRushStats.updateSkyRushStatsAccount(this.skyRushStats, this.player.getUniqueId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void logoutPlayer() {
/* 307 */     this.scoreboardSign.destroy();
/*     */     
/* 309 */     if (gamePlayers.get(this.player) != null) {
/* 310 */       gamePlayers.remove(this.player);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static GamePlayer getPlayer(Player player) {
/* 319 */     if (gamePlayers.get(player) == null)
/* 320 */       gamePlayers.put(player, new GamePlayer(player)); 
/* 321 */     return gamePlayers.get(player);
/*     */   }
/*     */ }


/* Location:              C:\Users\polux\OneDrive\Bureau\MarsMc\plugins\SkyRush.jar!\net\golema\skyrush\GamePlayer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */