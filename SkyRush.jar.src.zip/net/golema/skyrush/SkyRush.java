/*     */ package net.golema.skyrush;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.golema.api.games.servers.LoadashAPI;
/*     */ import net.golema.api.games.teams.Teams;
/*     */ import net.golema.api.utils.builders.FileManager;
/*     */ import net.golema.api.utils.world.WorldManager;
/*     */ import net.golema.api.utils.world.locations.Cuboid;
/*     */ import net.golema.loadash.servers.ServerStatus;
/*     */ import net.golema.skyrush.listeners.ListenerManager;
/*     */ import net.golema.skyrush.manager.GolemaEntity;
/*     */ import net.golema.skyrush.manager.kits.KitDefenseur;
/*     */ import net.golema.skyrush.manager.kits.KitFireman;
/*     */ import net.golema.skyrush.manager.kits.KitGladiator;
/*     */ import net.golema.skyrush.manager.kits.KitRunner;
/*     */ import net.golema.skyrush.manager.kits.KitVampire;
/*     */ import net.golema.skyrush.runnables.ScoreboardRunnable;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SkyRush
/*     */   extends JavaPlugin
/*     */ {
/*     */   private FileManager.Config mapConfig;
/*     */   private int maxHeight;
/*     */   private double golemHealth;
/*  35 */   private Map<Teams, Location> teamGolemLocationMap = new HashMap<>();
/*  36 */   private Map<Teams, GolemaEntity> teamGolemMap = new HashMap<>();
/*  37 */   private Map<Teams, Cuboid> teamCuboidMap = new HashMap<>();
/*  38 */   private Map<Teams, Location> teamShopLocationMap = new HashMap<>();
/*  39 */   private List<Cuboid> safeZoneList = new ArrayList<>();
/*  40 */   private List<Location> kitsNPCLocationList = new ArrayList<>();
/*     */   
/*  42 */   private List<Player> playerSpawnKillList = new ArrayList<>();
/*     */ 
/*     */ 
/*     */   
/*     */   public void onLoad() {
/*  47 */     this.mapConfig = WorldManager.loadGameServerMaps(LoadashAPI.getGolemaServer().getGameType());
/*  48 */     if (this.mapConfig == null)
/*  49 */       Bukkit.getServer().shutdown(); 
/*  50 */     saveDefaultConfig();
/*     */     
/*  52 */     super.onLoad();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  59 */     (new ListenerManager(Bukkit.getPluginManager())).registerListeners();
/*  60 */     (new ScoreboardRunnable()).runTaskTimer((Plugin)getPlugin(), 10L, 20L);
/*     */ 
/*     */     
/*  63 */     this.maxHeight = getMapConfig().get().getInt("maxHeightBlock");
/*  64 */     this.golemHealth = getMapConfig().get().getDouble("golemHealth");
/*     */ 
/*     */     
/*  67 */     LoadashAPI.enabledGameServer(LoadashAPI.getGolemaServer().getGameType(), 
/*  68 */         LoadashAPI.getGolemaServer().getServerType(), LoadashAPI.getGolemaServer().getMapInfos());
/*  69 */     if (LoadashAPI.isHostServer()) {
/*  70 */       LoadashAPI.setServerStatus(ServerStatus.HOST);
/*     */     }
/*     */     
/*  73 */     new KitDefenseur();
/*  74 */     new KitFireman();
/*  75 */     new KitVampire();
/*  76 */     new KitGladiator();
/*  77 */     new KitRunner();
/*     */     
/*  79 */     super.onEnable();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDisable() {
/*  84 */     super.onDisable();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxHeight() {
/*  91 */     return this.maxHeight;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getGolemHealth() {
/*  98 */     return this.golemHealth;
/*     */   }
/*     */   
/*     */   public Map<Teams, Location> getTeamGolemLocationMap() {
/* 102 */     return this.teamGolemLocationMap;
/*     */   }
/*     */   
/*     */   public Map<Teams, GolemaEntity> getTeamGolemMap() {
/* 106 */     return this.teamGolemMap;
/*     */   }
/*     */   
/*     */   public Map<Teams, Cuboid> getTeamCuboidMap() {
/* 110 */     return this.teamCuboidMap;
/*     */   }
/*     */   
/*     */   public Map<Teams, Location> getTeamShopLocationMap() {
/* 114 */     return this.teamShopLocationMap;
/*     */   }
/*     */   
/*     */   public List<Cuboid> getSafeZoneList() {
/* 118 */     return this.safeZoneList;
/*     */   }
/*     */   
/*     */   public List<Location> getKitsNPCLocationList() {
/* 122 */     return this.kitsNPCLocationList;
/*     */   }
/*     */   
/*     */   public List<Player> getPlayerSpawnKillList() {
/* 126 */     return this.playerSpawnKillList;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FileManager.Config getMapConfig() {
/* 133 */     return this.mapConfig;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SkyRush getPlugin() {
/* 140 */     return (SkyRush)getPlugin(SkyRush.class);
/*     */   }
/*     */ }


/* Location:              C:\Users\polux\OneDrive\Bureau\MarsMc\plugins\SkyRush.jar!\net\golema\skyrush\SkyRush.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */