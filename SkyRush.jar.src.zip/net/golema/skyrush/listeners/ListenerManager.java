/*    */ package net.golema.skyrush.listeners;
/*    */ 
/*    */ import net.golema.api.minecraft.listeners.games.KnockbackFixerListener;
/*    */ import net.golema.skyrush.SkyRush;
/*    */ import net.golema.skyrush.listeners.entity.EntityDeathListener;
/*    */ import net.golema.skyrush.listeners.entity.EntityInteractListener;
/*    */ import net.golema.skyrush.listeners.player.PlayerConnectListener;
/*    */ import net.golema.skyrush.listeners.player.PlayerDeathListener;
/*    */ import net.golema.skyrush.listeners.player.PlayerKitListener;
/*    */ import net.golema.skyrush.listeners.world.BlockListener;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ import org.bukkit.plugin.PluginManager;
/*    */ 
/*    */ public class ListenerManager
/*    */ {
/*    */   private PluginManager pluginManager;
/*    */   private Plugin plugin;
/*    */   
/*    */   public ListenerManager(PluginManager pluginManager) {
/* 21 */     this.pluginManager = pluginManager;
/* 22 */     this.plugin = (Plugin)SkyRush.getPlugin();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void registerListeners() {
/* 29 */     this.pluginManager.registerEvents((Listener)new KnockbackFixerListener(), this.plugin);
/*    */     
/* 31 */     this.pluginManager.registerEvents((Listener)new EntityDeathListener(), this.plugin);
/* 32 */     this.pluginManager.registerEvents((Listener)new EntityInteractListener(), this.plugin);
/*    */     
/* 34 */     this.pluginManager.registerEvents((Listener)new PlayerConnectListener(), this.plugin);
/* 35 */     this.pluginManager.registerEvents((Listener)new PlayerDeathListener(), this.plugin);
/* 36 */     this.pluginManager.registerEvents((Listener)new PlayerKitListener(), this.plugin);
/*    */     
/* 38 */     this.pluginManager.registerEvents((Listener)new BlockListener(), this.plugin);
/*    */   }
/*    */ }


/* Location:              C:\Users\polux\OneDrive\Bureau\MarsMc\plugins\SkyRush.jar!\net\golema\skyrush\listeners\ListenerManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */