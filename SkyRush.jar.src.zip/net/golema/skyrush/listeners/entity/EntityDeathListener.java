/*     */ package net.golema.skyrush.listeners.entity;
/*     */ 
/*     */ import net.golema.api.games.GameStatus;
/*     */ import net.golema.api.games.kits.KitsInfos;
/*     */ import net.golema.api.games.teams.Teams;
/*     */ import net.golema.api.players.stats.Stats;
/*     */ import net.golema.api.utils.GolemaAPI;
/*     */ import net.golema.api.utils.builders.titles.ActionBarBuilder;
/*     */ import net.golema.api.utils.builders.titles.TitleBuilder;
/*     */ import net.golema.api.utils.tools.SoundUtils;
/*     */ import net.golema.skyrush.GamePlayer;
/*     */ import net.golema.skyrush.SkyRush;
/*     */ import net.golema.skyrush.manager.GolemaEntity;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.Sound;
/*     */ import org.bukkit.entity.Golem;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.EventPriority;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.entity.EntityDamageEvent;
/*     */ import org.bukkit.event.entity.EntityDeathEvent;
/*     */ import org.bukkit.event.player.PlayerMoveEvent;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.potion.PotionEffect;
/*     */ import org.bukkit.potion.PotionEffectType;
/*     */ 
/*     */ public class EntityDeathListener
/*     */   implements Listener
/*     */ {
/*     */   @EventHandler(priority = EventPriority.LOWEST)
/*     */   public void onEntityDeath(EntityDeathEvent event) {
/*  36 */     if (event.getEntity() instanceof Golem) {
/*     */ 
/*     */       
/*  39 */       for (ItemStack itemStack : event.getDrops()) {
/*  40 */         itemStack.setType(Material.AIR);
/*     */       }
/*  42 */       Golem golem = (Golem)event.getEntity();
/*     */ 
/*     */       
/*  45 */       Teams teamsGolem = null;
/*  46 */       for (Teams teams : GolemaAPI.getGameSetting().getTeamManager().getTeamList()) {
/*  47 */         if (((GolemaEntity)SkyRush.getPlugin().getTeamGolemMap().get(teams)).getGolem().equals(golem))
/*  48 */           teamsGolem = teams; 
/*  49 */       }  if (teamsGolem == null) {
/*     */         return;
/*     */       }
/*     */       
/*  53 */       if (golem.getKiller() != null) {
/*  54 */         Player killerGolem = golem.getKiller();
/*  55 */         GamePlayer gamePlayerKiller = GamePlayer.getPlayer(killerGolem);
/*  56 */         gamePlayerKiller.addCoins(killerGolem, 10.0F, "Destruction d'un Golem");
/*  57 */         gamePlayerKiller.getPlayerStats().addCoinsWin(10.0F);
/*  58 */         gamePlayerKiller.getPlayerStats().addStats(Stats.GOLEMS_KILLS, 1);
/*     */       } 
/*     */ 
/*     */       
/*  62 */       Bukkit.broadcastMessage(
/*  63 */           GolemaAPI.getGameSetting().getGamePrefix() + ChatColor.YELLOW + "Le golem de l'équipe " + teamsGolem
/*  64 */           .getChatColor() + teamsGolem.getName() + ChatColor.YELLOW + " a succombé...");
/*     */ 
/*     */       
/*  67 */       for (Player playerOnline : Bukkit.getOnlinePlayers()) {
/*  68 */         SoundUtils.sendSound(playerOnline, Sound.ENDERDRAGON_DEATH);
/*  69 */         GamePlayer gamePlayer = GamePlayer.getPlayer(playerOnline);
/*  70 */         if (gamePlayer != null && teamsGolem != null && gamePlayer.getTeam() != null && gamePlayer
/*  71 */           .getTeam().equals(teamsGolem)) {
/*  72 */           (new TitleBuilder(ChatColor.RED + "│ ATTENTION │", ChatColor.YELLOW + "Vous pouvez désormais mourir."))
/*  73 */             .send(playerOnline);
/*  74 */           playerOnline.sendMessage(GolemaAPI.getGameSetting().getGamePrefix() + ChatColor.WHITE + "Votre Golem a été " + ChatColor.RED + "détruit" + ChatColor.WHITE + "...");
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @EventHandler(priority = EventPriority.LOW)
/*     */   public void onEntityDamage(EntityDamageEvent event) {
/*  84 */     if ((GameStatus.isStatus(GameStatus.GAME) && event.getCause().equals(EntityDamageEvent.DamageCause.FALLING_BLOCK)) || event
/*  85 */       .getCause().equals(EntityDamageEvent.DamageCause.FALL)) {
/*  86 */       event.setDamage(event.getDamage() / 100.0D * 40.0D);
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler(priority = EventPriority.HIGH)
/*     */   public void onPlayerMove(PlayerMoveEvent event) {
/*  92 */     Player player = event.getPlayer();
/*  93 */     GamePlayer gamePlayer = GamePlayer.getPlayer(player);
/*  94 */     Location location = player.getLocation();
/*     */     
/*  96 */     if (!GameStatus.isStatus(GameStatus.GAME)) {
/*     */       return;
/*     */     }
/*     */     
/* 100 */     if (gamePlayer != null && !gamePlayer.isSpectator() && 
/* 101 */       player.getLocation().getBlockY() <= 0) {
/* 102 */       player.damage(20.0D);
/*     */     }
/*     */ 
/*     */     
/* 106 */     Location locationSpawn = GolemaAPI.getGameSetting().getTeamManager().getTeamLocation(gamePlayer.getTeam());
/* 107 */     if (SkyRush.getPlugin().getPlayerSpawnKillList().contains(player) && player.getLocation().getBlock() != null && 
/* 108 */       !player.getLocation().getBlock().getType().equals(Material.AIR) && location
/* 109 */       .getBlockX() == locationSpawn.getBlockX() && location
/* 110 */       .getBlockZ() == locationSpawn.getBlockZ()) {
/* 111 */       location = GolemaAPI.getGameSetting().getTeamManager().getTeamLocation(gamePlayer.getTeam());
/* 112 */       player.teleport(location);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 117 */     for (Teams teams : GolemaAPI.getGameSetting().getTeamManager().getTeamList()) {
/* 118 */       Location locationGolem = (Location)SkyRush.getPlugin().getTeamGolemLocationMap().get(teams);
/* 119 */       if (location.getBlockX() == locationGolem.getBlockX() && location
/* 120 */         .getBlockZ() == locationGolem.getBlockZ() && (
/* 121 */         (GolemaEntity)SkyRush.getPlugin().getTeamGolemMap().get(Teams.RED)).getGolem() == null && 
/* 122 */         !((GolemaEntity)SkyRush.getPlugin().getTeamGolemMap().get(Teams.RED)).isDead()) {
/* 123 */         player.setVelocity(location.getDirection().multiply(1.5D));
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 128 */     Location from = event.getFrom();
/* 129 */     Location to = event.getTo();
/* 130 */     double x = Math.floor(from.getX());
/* 131 */     double z = Math.floor(from.getZ());
/*     */     
/* 133 */     if (Math.floor(to.getX()) != x || Math.floor(to.getZ()) != z)
/*     */     {
/* 135 */       if (gamePlayer != null && gamePlayer.getKit() != null && gamePlayer
/* 136 */         .getKit().getKitsInfo().equals(KitsInfos.SKYRUSH_DEFENSEUR)) {
/* 137 */         Teams teams = gamePlayer.getTeam();
/* 138 */         if (teams == null)
/*     */           return; 
/* 140 */         if (((Location)SkyRush.getPlugin().getTeamGolemLocationMap().get(teams)).distance(location) < 10.0D && 
/* 141 */           SkyRush.getPlugin().getTeamGolemMap().get(teams) != null && 
/* 142 */           !((GolemaEntity)SkyRush.getPlugin().getTeamGolemMap().get(teams)).isDead()) {
/* 143 */           (new ActionBarBuilder(ChatColor.RED + "❤ Régénération de protection...")).sendTo(player);
/* 144 */           PotionEffect potionEffect = new PotionEffect(PotionEffectType.REGENERATION, 35, 1);
/* 145 */           if (!player.getActivePotionEffects().contains(potionEffect))
/* 146 */             player.addPotionEffect(potionEffect); 
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\polux\OneDrive\Bureau\MarsMc\plugins\SkyRush.jar!\net\golema\skyrush\listeners\entity\EntityDeathListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */