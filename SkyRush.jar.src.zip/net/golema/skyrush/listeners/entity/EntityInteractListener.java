/*     */ package net.golema.skyrush.listeners.entity;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.golema.api.games.GameStatus;
/*     */ import net.golema.api.games.kits.KitsMenu;
/*     */ import net.golema.api.games.teams.Teams;
/*     */ import net.golema.api.utils.GolemaAPI;
/*     */ import net.golema.api.utils.builders.titles.ActionBarBuilder;
/*     */ import net.golema.api.utils.builders.titles.TitleBuilder;
/*     */ import net.golema.api.utils.tools.SoundUtils;
/*     */ import net.golema.skyrush.GamePlayer;
/*     */ import net.golema.skyrush.SkyRush;
/*     */ import net.golema.skyrush.manager.GolemaEntity;
/*     */ import net.golema.skyrush.manager.shop.ShopMainMenu;
/*     */ import net.md_5.bungee.api.ChatColor;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.Sound;
/*     */ import org.bukkit.entity.Golem;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.EventPriority;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.block.Action;
/*     */ import org.bukkit.event.entity.EntityDamageByEntityEvent;
/*     */ import org.bukkit.event.player.PlayerInteractAtEntityEvent;
/*     */ import org.bukkit.event.player.PlayerInteractEvent;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ public class EntityInteractListener
/*     */   implements Listener {
/*  34 */   private List<Player> messageSpam = new ArrayList<>();
/*  35 */   private List<Player> titleWarnSpam = new ArrayList<>();
/*  36 */   private List<Player> spamTracker = new ArrayList<>();
/*     */   
/*     */   @EventHandler(priority = EventPriority.NORMAL)
/*     */   public void onPlayerInteract(PlayerInteractEvent event) {
/*  40 */     Player player = event.getPlayer();
/*  41 */     GamePlayer gamePlayer = GamePlayer.getPlayer(player);
/*  42 */     if (event.getItem() == null)
/*     */       return; 
/*  44 */     if (event.getItem().getType() == null)
/*     */       return; 
/*  46 */     if (event.getItem().getType().equals(Material.AIR))
/*     */       return; 
/*  48 */     if (event.getAction() != Action.RIGHT_CLICK_BLOCK && event.getAction() != Action.RIGHT_CLICK_AIR)
/*     */       return; 
/*  50 */     switch (event.getItem().getType()) {
/*     */ 
/*     */       
/*     */       case COMPASS:
/*  54 */         if (GameStatus.isStatus(GameStatus.GAME)) {
/*  55 */           Player target = gamePlayer.getTrackerTargetPlayer(Double.MAX_VALUE);
/*  56 */           event.setCancelled(true);
/*  57 */           if (!this.spamTracker.contains(player)) {
/*     */             
/*  59 */             if (target == null) {
/*  60 */               player.sendMessage(GolemaAPI.getGameSetting().getGamePrefix() + ChatColor.RED + "Impossible de trouver un joueur aux alentours.");
/*     */               
/*  62 */               this.spamTracker.add(player);
/*     */               
/*     */               return;
/*     */             } 
/*  66 */             GamePlayer gamePlayerTarget = GamePlayer.getPlayer(target);
/*  67 */             double distante = target.getLocation().distance(player.getLocation());
/*  68 */             player.setCompassTarget(target.getLocation());
/*  69 */             player.sendMessage(ChatColor.GRAY + "Vous trackez " + gamePlayerTarget.getTeam().getChatColor() + gamePlayerTarget
/*  70 */                 .getTeam().getPrefix() + " " + target.getName() + ChatColor.GRAY + " qui se trouve à " + ChatColor.YELLOW + 
/*  71 */                 (int)Math.round(distante) + " blocks" + ChatColor.GRAY + ".");
/*     */             
/*  73 */             this.spamTracker.add(player);
/*  74 */             removeSpamList(player, 4, this.spamTracker);
/*     */           } 
/*     */         } 
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @EventHandler(priority = EventPriority.LOW)
/*     */   public void onPlayerInteractAtEntity(PlayerInteractAtEntityEvent event) {
/*  87 */     Player player = event.getPlayer();
/*     */ 
/*     */     
/*  90 */     for (Location locationArmorStand : SkyRush.getPlugin().getKitsNPCLocationList()) {
/*  91 */       if (locationArmorStand.equals(event.getRightClicked().getLocation())) {
/*  92 */         if (!GamePlayer.getPlayer(player).canChangeKit()) {
/*  93 */           event.setCancelled(true);
/*  94 */           player.sendMessage(GolemaAPI.getGameSetting().getGamePrefix() + ChatColor.RED + "Vous avez atteint la limite de changement de kits...");
/*     */           
/*  96 */           SoundUtils.sendSound(player, Sound.BAT_HURT);
/*     */           return;
/*     */         } 
/*  99 */         new KitsMenu(player);
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/*     */     
/* 105 */     for (Teams teams : GolemaAPI.getGameSetting().getTeamManager().getTeamList()) {
/* 106 */       if (((Location)SkyRush.getPlugin().getTeamShopLocationMap().get(teams)).equals(event.getRightClicked().getLocation())) {
/* 107 */         new ShopMainMenu(player);
/*     */         break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @EventHandler(priority = EventPriority.LOWEST)
/*     */   public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
/* 117 */     if (event.getDamager() instanceof Player && event.getEntity() instanceof Player) {
/*     */       
/* 119 */       Player player = (Player)event.getDamager();
/* 120 */       Player target = (Player)event.getEntity();
/*     */ 
/*     */       
/* 123 */       if (SkyRush.getPlugin().getPlayerSpawnKillList().contains(target)) {
/* 124 */         (new ActionBarBuilder(ChatColor.RED + "Evitez le spawn-kill.")).sendTo(player);
/* 125 */         event.setCancelled(true);
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/*     */     
/* 131 */     if (event.getDamager() instanceof Player && event.getEntity() instanceof Golem) {
/*     */       
/* 133 */       Player player = (Player)event.getDamager();
/* 134 */       GamePlayer gamePlayer = GamePlayer.getPlayer(player);
/* 135 */       Golem golem = (Golem)event.getEntity();
/* 136 */       Teams teams = gamePlayer.getTeam();
/*     */ 
/*     */       
/* 139 */       if (player == null || gamePlayer == null || golem == null || teams == null) {
/* 140 */         event.setCancelled(true);
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 145 */       if (((GolemaEntity)SkyRush.getPlugin().getTeamGolemMap().get(teams)).getGolem().equals(golem)) {
/* 146 */         if (!this.messageSpam.contains(player)) {
/* 147 */           player.sendMessage(ChatColor.GOLD + "" + ChatColor.BOLD + "ATTENTION" + ChatColor.GRAY + "│ " + ChatColor.RED + "Vous ne pouvez pas attaquer votre Golem...");
/*     */           
/* 149 */           SoundUtils.sendSound(player, Sound.BAT_HURT);
/* 150 */           this.messageSpam.add(player);
/* 151 */           removeSpamList(player, 5, this.messageSpam);
/*     */         } 
/* 153 */         event.setCancelled(true);
/*     */       } else {
/*     */         
/* 156 */         gamePlayer.addTokens(1, true);
/* 157 */         Bukkit.getOnlinePlayers().forEach(playerOnline -> {
/*     */               GamePlayer gamePlayerTarget = GamePlayer.getPlayer(playerOnline);
/*     */               if (gamePlayerTarget != null && gamePlayerTarget.getTeam() != null && !gamePlayerTarget.isSpectator() && !gamePlayerTarget.getTeam().equals(teams) && ((GolemaEntity)SkyRush.getPlugin().getTeamGolemMap().get(gamePlayerTarget.getTeam())).getGolem().equals(golem) && !this.titleWarnSpam.contains(playerOnline)) {
/*     */                 (new TitleBuilder(ChatColor.RED + "│ ATTENTION│", ChatColor.GOLD + "Votre golem est attaqué...")).send(playerOnline);
/*     */                 SoundUtils.sendSound(playerOnline, Sound.WITHER_HURT);
/*     */                 this.titleWarnSpam.add(playerOnline);
/*     */                 removeSpamList(playerOnline, 5, this.titleWarnSpam);
/*     */               } 
/*     */             });
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void removeSpamList(final Player player, int time, final List<Player> list) {
/* 184 */     Bukkit.getScheduler().runTaskLater((Plugin)SkyRush.getPlugin(), new Runnable()
/*     */         {
/*     */           public void run() {
/* 187 */             list.remove(player);
/*     */           }
/*     */         },  time * 20L);
/*     */   }
/*     */ }


/* Location:              C:\Users\polux\OneDrive\Bureau\MarsMc\plugins\SkyRush.jar!\net\golema\skyrush\listeners\entity\EntityInteractListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */