/*    */ package net.golema.skyrush.listeners.player;
/*    */ 
/*    */ import net.golema.api.games.GameInterface;
/*    */ import net.golema.api.games.GameStatus;
/*    */ import net.golema.api.minecraft.listeners.custom.GolemaPlayerJoinEvent;
/*    */ import net.golema.api.minecraft.listeners.custom.GolemaPlayerQuitEvent;
/*    */ import net.golema.api.players.stats.IStats;
/*    */ import net.golema.api.players.stats.games.SkyRushStats;
/*    */ import net.golema.api.utils.GolemaAPI;
/*    */ import net.golema.skyrush.GamePlayer;
/*    */ import net.golema.skyrush.manager.GameLoaderManager;
/*    */ import net.golema.skyrush.manager.WinManager;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.EventPriority;
/*    */ import org.bukkit.event.Listener;
/*    */ 
/*    */ public class PlayerConnectListener
/*    */   implements Listener {
/*    */   @EventHandler(priority = EventPriority.HIGHEST)
/*    */   public void onPlayerConnect(GolemaPlayerJoinEvent event) {
/* 22 */     Player player = event.getPlayer();
/* 23 */     GamePlayer gamePlayer = GamePlayer.getPlayer(player);
/*    */ 
/*    */     
/* 26 */     if (!GameStatus.isStatus(GameStatus.LOBBY)) {
/* 27 */       gamePlayer.setSpectator();
/* 28 */       gamePlayer.loadGameScoreboard();
/* 29 */       GolemaAPI.getGameSetting().teleportPlayerRandomAlivePlayer(player);
/*    */       
/*    */       return;
/*    */     } 
/*    */     
/* 34 */     if (GolemaAPI.getGameSetting().getGameInterface() == null)
/* 35 */       GolemaAPI.getGameSetting().setGameInterface((GameInterface)new GameLoaderManager()); 
/* 36 */     gamePlayer.loadScoreboard();
/* 37 */     GolemaAPI.getGameSetting().getKitManager().applyLastKit(player.getUniqueId(), (IStats)gamePlayer.getPlayerStats());
/*    */   }
/*    */   
/*    */   @EventHandler(priority = EventPriority.LOWEST)
/*    */   public void onPlayerQuit(GolemaPlayerQuitEvent event) {
/* 42 */     Player player = event.getPlayer();
/* 43 */     GamePlayer gamePlayer = GamePlayer.getPlayer(player);
/*    */ 
/*    */     
/* 46 */     if (GameStatus.isStatus(GameStatus.GAME) && !gamePlayer.isSpectator())
/* 47 */       SkyRushStats.updateSkyRushStatsAccount(SkyRushStats.get(player.getUniqueId()), player.getUniqueId()); 
/* 48 */     gamePlayer.logoutPlayer();
/*    */ 
/*    */     
/* 51 */     new WinManager();
/*    */   }
/*    */ }


/* Location:              C:\Users\polux\OneDrive\Bureau\MarsMc\plugins\SkyRush.jar!\net\golema\skyrush\listeners\player\PlayerConnectListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */