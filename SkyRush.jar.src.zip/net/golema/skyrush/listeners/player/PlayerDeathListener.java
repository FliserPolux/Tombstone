/*     */ package net.golema.skyrush.listeners.player;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import net.golema.api.games.kits.KitsInfos;
/*     */ import net.golema.api.games.teams.TeamManager;
/*     */ import net.golema.api.games.teams.Teams;
/*     */ import net.golema.api.players.stats.Stats;
/*     */ import net.golema.api.utils.GolemaAPI;
/*     */ import net.golema.api.utils.builders.effects.Particles;
/*     */ import net.golema.api.utils.builders.titles.TitleBuilder;
/*     */ import net.golema.api.utils.tools.SoundUtils;
/*     */ import net.golema.skyrush.GamePlayer;
/*     */ import net.golema.skyrush.SkyRush;
/*     */ import net.golema.skyrush.manager.GolemaEntity;
/*     */ import net.golema.skyrush.manager.WinManager;
/*     */ import net.md_5.bungee.api.ChatColor;
/*     */ import net.minecraft.server.v1_8_R3.PacketPlayInClientCommand;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.Sound;
/*     */ import org.bukkit.craftbukkit.v1_8_R3.entity.CraftPlayer;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.EventPriority;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.entity.PlayerDeathEvent;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PlayerDeathListener
/*     */   implements Listener
/*     */ {
/*     */   private List<String> deathKillerMessageList;
/*     */   private List<String> deathSoloMessageList;
/*     */   
/*     */   public PlayerDeathListener() {
/*  43 */     this.deathKillerMessageList = new ArrayList<>();
/*  44 */     this.deathKillerMessageList.add("{name} a été tué par {killer}.");
/*  45 */     this.deathKillerMessageList.add("{killer} a achevé le joueur {name}.");
/*  46 */     this.deathKillerMessageList.add("{name} s'est fait rekt par {killer}.");
/*  47 */     this.deathKillerMessageList.add("{name} a capitulé devant {killer}.");
/*  48 */     this.deathKillerMessageList.add("{name} s'est fait supprimé par {killer}.");
/*     */ 
/*     */     
/*  51 */     this.deathSoloMessageList = new ArrayList<>();
/*  52 */     this.deathSoloMessageList.add("{name} est mort.");
/*  53 */     this.deathSoloMessageList.add("{name} vient de succomber de ses blessures.");
/*  54 */     this.deathSoloMessageList.add("Un héros nous a quitté, {name} est mort.");
/*     */   }
/*     */ 
/*     */   
/*     */   @EventHandler(priority = EventPriority.HIGH)
/*     */   public void onPlayerDeath(PlayerDeathEvent event) {
/*  60 */     Player player = event.getEntity();
/*  61 */     GamePlayer gamePlayer = GamePlayer.getPlayer(player);
/*  62 */     Teams playerTeam = gamePlayer.getTeam();
/*  63 */     Player killer = event.getEntity().getKiller();
/*  64 */     event.setDeathMessage(null);
/*     */     
/*  66 */     if (killer != null) {
/*  67 */       GamePlayer gamePlayerKiller = GamePlayer.getPlayer(killer);
/*  68 */       Teams killerTeam = gamePlayerKiller.getTeam();
/*  69 */       GamePlayer.getPlayer(killer).addKills();
/*  70 */       Bukkit.broadcastMessage(ChatColor.GRAY + ((String)this.deathKillerMessageList
/*  71 */           .get((new Random()).nextInt(this.deathKillerMessageList.size())))
/*  72 */           .replace("{name}", playerTeam
/*  73 */             .getChatColor() + playerTeam.getPrefix() + " " + player.getName() + ChatColor.GRAY)
/*     */           
/*  75 */           .replace("{killer}", killerTeam.getChatColor() + killerTeam.getPrefix() + " " + killer
/*  76 */             .getName() + ChatColor.GRAY));
/*  77 */       SoundUtils.sendSound(killer, Sound.NOTE_PIANO);
/*  78 */       gamePlayerKiller.addCoins(killer, 2.0F, "Kills de " + player.getName());
/*  79 */       gamePlayerKiller.addTokens(2, true);
/*  80 */       gamePlayerKiller.getPlayerStats().addStats(Stats.KILLS, 1);
/*  81 */       gamePlayerKiller.getPlayerStats().addCoinsWin(2.0F);
/*     */       
/*  83 */       if (gamePlayerKiller.getKit() != null && gamePlayerKiller
/*  84 */         .getKit().getKitsInfo().equals(KitsInfos.SKYRUSH_VAMPIRE)) {
/*  85 */         double health = 8.0D;
/*  86 */         if (killer.getHealth() + health > killer.getMaxHealth()) {
/*  87 */           killer.setHealth(killer.getMaxHealth());
/*     */         } else {
/*  89 */           killer.setHealth(killer.getHealth() + health);
/*  90 */         }  SoundUtils.sendSound(player, Sound.NOTE_PIANO);
/*  91 */         Particles.HEART.display(0.0F, 0.0F, 0.0F, 1.0F, 10, player.getLocation(), 32.0D);
/*     */       } 
/*     */     } else {
/*  94 */       Bukkit.broadcastMessage(ChatColor.GRAY + ((String)this.deathSoloMessageList
/*  95 */           .get((new Random()).nextInt(this.deathSoloMessageList.size())))
/*  96 */           .replace("{name}", playerTeam.getChatColor() + playerTeam.getPrefix() + " " + player
/*  97 */             .getName() + ChatColor.GRAY));
/*     */     } 
/*     */     
/* 100 */     for (ItemStack itemStack : event.getDrops())
/* 101 */       itemStack.setType(Material.AIR); 
/* 102 */     GamePlayer.getPlayer(player).addDeaths();
/* 103 */     GamePlayer.getPlayer(player).getPlayerStats().addStats(Stats.DEATHS, 1);
/* 104 */     instantDeath(player, 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void instantDeath(final Player player, int time) {
/* 115 */     Bukkit.getScheduler().runTaskLater((Plugin)SkyRush.getPlugin(), new Runnable()
/*     */         {
/*     */           public void run()
/*     */           {
/* 119 */             (((CraftPlayer)player).getHandle()).playerConnection
/* 120 */               .a(new PacketPlayInClientCommand(PacketPlayInClientCommand.EnumClientCommand.PERFORM_RESPAWN));
/*     */ 
/*     */             
/* 123 */             GamePlayer gamePlayer = GamePlayer.getPlayer(player);
/* 124 */             Teams teams = gamePlayer.getTeam();
/* 125 */             if (teams != null && ((GolemaEntity)SkyRush.getPlugin().getTeamGolemMap().get(teams)).isDead()) {
/* 126 */               gamePlayer.setSpectator();
/* 127 */               GolemaAPI.getGameSetting().teleportPlayerRandomAlivePlayer(player);
/* 128 */               SoundUtils.sendSound(player, Sound.BLAZE_DEATH);
/* 129 */               Bukkit.getWorld(GolemaAPI.getGameSetting().getWorldName())
/* 130 */                 .strikeLightningEffect(player.getLocation());
/* 131 */               (new TitleBuilder(ChatColor.DARK_RED + "✘ Elimination ✘", ChatColor.RED + "Vous êtes maintenant éliminé..."))
/* 132 */                 .send(player);
/* 133 */               gamePlayer.sendReplayMessage(player);
/* 134 */               new WinManager();
/*     */               
/*     */               return;
/*     */             } 
/*     */             
/* 139 */             SkyRush.getPlugin().getPlayerSpawnKillList().add(player);
/* 140 */             TeamManager teamManager = GolemaAPI.getGameSetting().getTeamManager();
/* 141 */             Location location = teamManager.getTeamLocation(gamePlayer.getTeam());
/* 142 */             player.teleport(location);
/* 143 */             (new TitleBuilder("", ChatColor.GOLD + "Respawn...")).send(player);
/* 144 */             gamePlayer.sendStuff();
/* 145 */             PlayerDeathListener.this.removeSpawnkillList(player, 5, SkyRush.getPlugin().getPlayerSpawnKillList());
/*     */           }
/*     */         }time);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void removeSpawnkillList(final Player player, int time, final List<Player> list) {
/* 159 */     Bukkit.getScheduler().runTaskLater((Plugin)SkyRush.getPlugin(), new Runnable()
/*     */         {
/*     */           public void run() {
/* 162 */             list.remove(player);
/*     */           }
/*     */         },  time * 20L);
/*     */   }
/*     */ }


/* Location:              C:\Users\polux\OneDrive\Bureau\MarsMc\plugins\SkyRush.jar!\net\golema\skyrush\listeners\player\PlayerDeathListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */