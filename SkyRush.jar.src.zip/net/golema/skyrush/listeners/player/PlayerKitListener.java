/*    */ package net.golema.skyrush.listeners.player;
/*    */ 
/*    */ import net.golema.api.games.GameStatus;
/*    */ import net.golema.api.minecraft.listeners.custom.PlayerKitChangeEvent;
/*    */ import net.golema.api.players.stats.games.SkyRushStats;
/*    */ import net.golema.skyrush.GamePlayer;
/*    */ import net.md_5.bungee.api.ChatColor;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.EventPriority;
/*    */ import org.bukkit.event.Listener;
/*    */ 
/*    */ public class PlayerKitListener
/*    */   implements Listener
/*    */ {
/*    */   @EventHandler(priority = EventPriority.HIGHEST)
/*    */   public void onChangeKit(PlayerKitChangeEvent event) {
/* 18 */     Player player = event.getPlayer();
/* 19 */     GamePlayer gamePlayer = GamePlayer.getPlayer(player);
/* 20 */     if (!GameStatus.isStatus(GameStatus.GAME))
/*    */       return; 
/* 22 */     gamePlayer.addKitChange();
/* 23 */     gamePlayer.scoreboardSign.setLine(3, ChatColor.WHITE + "Kit : " + ChatColor.LIGHT_PURPLE + event
/* 24 */         .getKitsInfos().getName());
/* 25 */     SkyRushStats.get(player.getUniqueId()).setLastKit(gamePlayer.getKit().getKitsInfo());
/* 26 */     if (gamePlayer != null)
/* 27 */       gamePlayer.sendStuff(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\polux\OneDrive\Bureau\MarsMc\plugins\SkyRush.jar!\net\golema\skyrush\listeners\player\PlayerKitListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */