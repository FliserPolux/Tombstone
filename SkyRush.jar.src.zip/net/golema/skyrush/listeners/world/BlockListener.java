/*     */ package net.golema.skyrush.listeners.world;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import net.golema.api.games.GameStatus;
/*     */ import net.golema.api.utils.builders.titles.ActionBarBuilder;
/*     */ import net.golema.api.utils.tools.SoundUtils;
/*     */ import net.golema.api.utils.world.locations.Cuboid;
/*     */ import net.golema.skyrush.SkyRush;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Sound;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.EventPriority;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.block.BlockBreakEvent;
/*     */ import org.bukkit.event.block.BlockPlaceEvent;
/*     */ 
/*     */ 
/*     */ public class BlockListener
/*     */   implements Listener
/*     */ {
/*  25 */   private Map<Block, Location> blocksProtectionMap = new HashMap<>();
/*     */ 
/*     */   
/*     */   @EventHandler(priority = EventPriority.LOWEST)
/*     */   public void onBlockPlace(BlockPlaceEvent event) {
/*  30 */     Player player = event.getPlayer();
/*  31 */     SkyRush skyRush = SkyRush.getPlugin();
/*  32 */     Block block = event.getBlock();
/*     */ 
/*     */     
/*  35 */     if (!GameStatus.isStatus(GameStatus.GAME)) {
/*  36 */       event.setCancelled(true);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  41 */     if (block.getLocation().getBlockY() >= skyRush.getMaxHeight()) {
/*  42 */       event.setCancelled(true);
/*  43 */       (new ActionBarBuilder(ChatColor.DARK_RED + "" + ChatColor.BOLD + "ATTENTION" + ChatColor.GRAY + "│ " + ChatColor.RED + "Vous ne pouvez pas poser de blocs à cette hauteur..."))
/*  44 */         .sendTo(player);
/*  45 */       SoundUtils.sendSound(player, Sound.VILLAGER_NO);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  50 */     for (Cuboid cuboid : skyRush.getSafeZoneList()) {
/*  51 */       if (cuboid != null && cuboid.IsArena(block.getLocation())) {
/*  52 */         event.setCancelled(true);
/*  53 */         (new ActionBarBuilder(ChatColor.DARK_RED + "" + ChatColor.BOLD + "ATTENTION" + ChatColor.GRAY + "│ " + ChatColor.RED + "Vous ne pouvez pas poser de blocs ici..."))
/*  54 */           .sendTo(player);
/*  55 */         SoundUtils.sendSound(player, Sound.VILLAGER_NO);
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/*     */     
/*  61 */     this.blocksProtectionMap.put(block, block.getLocation());
/*     */   }
/*     */ 
/*     */   
/*     */   @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
/*     */   public void onBlockBreak(BlockBreakEvent event) {
/*  67 */     Player player = event.getPlayer();
/*  68 */     SkyRush skyRush = SkyRush.getPlugin();
/*  69 */     Block block = event.getBlock();
/*     */ 
/*     */     
/*  72 */     if (!GameStatus.isStatus(GameStatus.GAME)) {
/*  73 */       event.setCancelled(true);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  78 */     for (Cuboid cuboid : skyRush.getSafeZoneList()) {
/*  79 */       if (cuboid != null && cuboid.IsArena(block.getLocation())) {
/*  80 */         event.setCancelled(true);
/*  81 */         warnBreakBlock(player);
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/*     */     
/*  87 */     if (!this.blocksProtectionMap.containsKey(block) && 
/*  88 */       !block.getLocation().equals(this.blocksProtectionMap.get(block))) {
/*  89 */       event.setCancelled(true);
/*  90 */       warnBreakBlock(player);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  95 */     this.blocksProtectionMap.remove(block);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void warnBreakBlock(Player player) {
/* 104 */     (new ActionBarBuilder(ChatColor.DARK_RED + "" + ChatColor.BOLD + "ATTENTION" + ChatColor.GRAY + "│ " + ChatColor.RED + "Vous ne pouvez détruire ces blocs-là..."))
/* 105 */       .sendTo(player);
/* 106 */     SoundUtils.sendSound(player, Sound.VILLAGER_NO);
/*     */   }
/*     */ }


/* Location:              C:\Users\polux\OneDrive\Bureau\MarsMc\plugins\SkyRush.jar!\net\golema\skyrush\listeners\world\BlockListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */