/*     */ package net.golema.skyrush.manager;
/*     */ 
/*     */ import net.golema.api.games.GameInterface;
/*     */ import net.golema.api.games.GameMessages;
/*     */ import net.golema.api.games.servers.LoadashAPI;
/*     */ import net.golema.api.games.teams.TeamManager;
/*     */ import net.golema.api.games.teams.Teams;
/*     */ import net.golema.api.players.stats.Stats;
/*     */ import net.golema.api.utils.GolemaAPI;
/*     */ import net.golema.api.utils.builders.items.ItemFactory;
/*     */ import net.golema.api.utils.builders.items.head.CustomSkull;
/*     */ import net.golema.api.utils.builders.items.head.TextureHeadLink;
/*     */ import net.golema.api.utils.builders.scoreboards.games.HealthBoardUtils;
/*     */ import net.golema.api.utils.builders.scoreboards.games.KillBoardUtils;
/*     */ import net.golema.api.utils.builders.titles.TitleBuilder;
/*     */ import net.golema.api.utils.tools.SoundUtils;
/*     */ import net.golema.api.utils.world.locations.Cuboid;
/*     */ import net.golema.skyrush.GamePlayer;
/*     */ import net.golema.skyrush.SkyRush;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.Color;
/*     */ import org.bukkit.Difficulty;
/*     */ import org.bukkit.GameMode;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.Sound;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.WorldBorder;
/*     */ import org.bukkit.entity.ArmorStand;
/*     */ import org.bukkit.entity.EntityType;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ public class GameLoaderManager implements GameInterface {
/*     */   private TeamManager teamManager;
/*  38 */   private World world = Bukkit.getWorld(GolemaAPI.getGameSetting().getWorldName());
/*  39 */   private SkyRush skyRush = SkyRush.getPlugin();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GameLoaderManager() {
/*  47 */     this.teamManager = GolemaAPI.getGameSetting().getTeamManager();
/*  48 */     this.teamManager.getTeamsLocation().clear();
/*  49 */     this.skyRush.getTeamGolemLocationMap().clear();
/*  50 */     this.skyRush.getTeamGolemMap().clear();
/*  51 */     this.skyRush.getTeamCuboidMap().clear();
/*  52 */     this.skyRush.getSafeZoneList().clear();
/*     */ 
/*     */     
/*  55 */     for (Teams teams : GolemaAPI.getGameSetting().getTeamManager().getTeamList()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  66 */       Location location = new Location(this.world, SkyRush.getPlugin().getMapConfig().get().getDouble("SpawnLocation." + teams.getName() + ".x"), SkyRush.getPlugin().getMapConfig().get().getDouble("SpawnLocation." + teams.getName() + ".y") + 3.5D, SkyRush.getPlugin().getMapConfig().get().getDouble("SpawnLocation." + teams.getName() + ".z"), (float)SkyRush.getPlugin().getMapConfig().get().getDouble("SpawnLocation." + teams.getName() + ".yaw"), 0.0F);
/*     */       
/*  68 */       this.teamManager.setTeamLocation(teams, location);
/*  69 */       location.getChunk().load();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  80 */       location = new Location(this.world, SkyRush.getPlugin().getMapConfig().get().getDouble("GolemLocation." + teams.getName() + ".x"), SkyRush.getPlugin().getMapConfig().get().getDouble("GolemLocation." + teams.getName() + ".y"), SkyRush.getPlugin().getMapConfig().get().getDouble("GolemLocation." + teams.getName() + ".z"), (float)SkyRush.getPlugin().getMapConfig().get().getDouble("GolemLocation." + teams.getName() + ".yaw"), 0.0F);
/*     */       
/*  82 */       this.skyRush.getTeamGolemLocationMap().put(teams, location);
/*  83 */       location.getChunk().load();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  94 */       location = new Location(this.world, SkyRush.getPlugin().getMapConfig().get().getDouble("NPCKitsLocation." + teams.getName() + ".x"), SkyRush.getPlugin().getMapConfig().get().getDouble("NPCKitsLocation." + teams.getName() + ".y"), SkyRush.getPlugin().getMapConfig().get().getDouble("NPCKitsLocation." + teams.getName() + ".z"), (float)SkyRush.getPlugin().getMapConfig().get().getDouble("NPCKitsLocation." + teams.getName() + ".yaw"), 0.0F);
/*     */       
/*  96 */       this.skyRush.getKitsNPCLocationList().add(location);
/*  97 */       location.getChunk().load();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 108 */       location = new Location(this.world, SkyRush.getPlugin().getMapConfig().get().getDouble("NPCShopLocation." + teams.getName() + ".x"), SkyRush.getPlugin().getMapConfig().get().getDouble("NPCShopLocation." + teams.getName() + ".y"), SkyRush.getPlugin().getMapConfig().get().getDouble("NPCShopLocation." + teams.getName() + ".z"), (float)SkyRush.getPlugin().getMapConfig().get().getDouble("NPCShopLocation." + teams.getName() + ".yaw"), 0.0F);
/*     */       
/* 110 */       this.skyRush.getTeamShopLocationMap().put(teams, location);
/* 111 */       location.getChunk().load();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 120 */       Location locationMin = new Location(this.world, SkyRush.getPlugin().getMapConfig().get().getDouble("GolemZone." + teams.getName() + ".min.x"), SkyRush.getPlugin().getMapConfig().get().getDouble("GolemZone." + teams.getName() + ".min.y"), SkyRush.getPlugin().getMapConfig().get().getDouble("GolemZone." + teams.getName() + ".min.z"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 127 */       Location locationMax = new Location(this.world, SkyRush.getPlugin().getMapConfig().get().getDouble("GolemZone." + teams.getName() + ".max.x"), SkyRush.getPlugin().getMapConfig().get().getDouble("GolemZone." + teams.getName() + ".max.y"), SkyRush.getPlugin().getMapConfig().get().getDouble("GolemZone." + teams.getName() + ".max.z"));
/* 128 */       Cuboid cuboid = new Cuboid(locationMin, locationMax);
/* 129 */       this.skyRush.getTeamCuboidMap().put(teams, cuboid);
/* 130 */       this.skyRush.getSafeZoneList().add(cuboid);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 135 */     int zoneCount = SkyRush.getPlugin().getMapConfig().get().getInt("ProtectedZone.zoneCount");
/* 136 */     for (int i = 1; i <= zoneCount; i++) {
/*     */ 
/*     */ 
/*     */       
/* 140 */       Location locationMin = new Location(this.world, SkyRush.getPlugin().getMapConfig().get().getDouble("ProtectedZone." + i + ".min.x"), SkyRush.getPlugin().getMapConfig().get().getDouble("ProtectedZone." + i + ".min.y"), SkyRush.getPlugin().getMapConfig().get().getDouble("ProtectedZone." + i + ".min.z"));
/*     */ 
/*     */ 
/*     */       
/* 144 */       Location locationMax = new Location(this.world, SkyRush.getPlugin().getMapConfig().get().getDouble("ProtectedZone." + i + ".max.x"), SkyRush.getPlugin().getMapConfig().get().getDouble("ProtectedZone." + i + ".max.y"), SkyRush.getPlugin().getMapConfig().get().getDouble("ProtectedZone." + i + ".max.z"));
/* 145 */       Cuboid cuboid = new Cuboid(locationMin, locationMax);
/* 146 */       this.skyRush.getSafeZoneList().add(cuboid);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void initGame() {
/* 153 */     LoadashAPI.getGolemaServer().setJoinable(false);
/*     */ 
/*     */     
/* 156 */     Bukkit.getOnlinePlayers().forEach(playerOnline -> {
/*     */           GamePlayer gamePlayer = GamePlayer.getPlayer(playerOnline);
/*     */           
/*     */           playerOnline.sendMessage(GolemaAPI.getGameSetting().getGamePrefix() + ChatColor.GREEN + "Téléportation en cours, chargement de la partie...");
/*     */           
/*     */           this.teamManager.addInRandomTeam(playerOnline);
/*     */           
/*     */           playerOnline.teleport(this.teamManager.getTeamLocation(gamePlayer.getTeam()));
/*     */           
/*     */           gamePlayer.loadGameScoreboard();
/*     */           
/*     */           new KillBoardUtils(playerOnline);
/*     */           
/*     */           new HealthBoardUtils(playerOnline);
/*     */           
/*     */           playerOnline.setMaxHealth(20.0D);
/*     */           
/*     */           playerOnline.setHealth(20.0D);
/*     */           
/*     */           gamePlayer.getPlayerStats().addStats(Stats.GAMEPLAYED, 1);
/*     */           
/*     */           if (gamePlayer.getKit() != null) {
/*     */             gamePlayer.getPlayerStats().setLastKit(gamePlayer.getKit().getKitsInfo());
/*     */           }
/*     */           
/*     */           playerOnline.setGameMode(GameMode.SURVIVAL);
/*     */           
/*     */           playerOnline.getInventory().clear();
/*     */           
/*     */           gamePlayer.sendStuff();
/*     */           
/*     */           playerOnline.sendMessage(GolemaAPI.getGameSetting().getGamePrefix() + ChatColor.WHITE + "Vous êtes dans l'équipe : " + gamePlayer.getTeam().getChatColor() + gamePlayer.getTeam().getName());
/*     */         });
/*     */     
/* 190 */     this.world.setSpawnLocation(-1000, 125, -1000);
/* 191 */     this.world.setDifficulty(Difficulty.EASY);
/* 192 */     this.world.setPVP(true);
/*     */ 
/*     */     
/* 195 */     WorldBorder worldBorder = this.world.getWorldBorder();
/* 196 */     worldBorder.setCenter(SkyRush.getPlugin().getMapConfig().get().getDouble("Worldborder.center.x"), 
/* 197 */         SkyRush.getPlugin().getMapConfig().get().getDouble("Worldborder.center.z"));
/* 198 */     worldBorder.setSize(SkyRush.getPlugin().getMapConfig().get().getDouble("Worldborder.size"));
/* 199 */     worldBorder.setWarningDistance(10);
/*     */ 
/*     */     
/* 202 */     Bukkit.getScheduler().runTaskLater((Plugin)SkyRush.getPlugin(), new Runnable()
/*     */         {
/*     */           
/*     */           public void run()
/*     */           {
/* 207 */             Location golemLocationRed = (Location)GameLoaderManager.this.skyRush.getTeamGolemLocationMap().get(Teams.RED);
/* 208 */             SkyRush.getPlugin().getTeamGolemMap().put(Teams.RED, new GolemaEntity(Teams.RED, Teams.RED
/* 209 */                   .getName(), golemLocationRed));
/* 210 */             ((GolemaEntity)SkyRush.getPlugin().getTeamGolemMap().get(Teams.RED)).loadArmorstand();
/*     */             
/* 212 */             Location golemLocationBlue = (Location)GameLoaderManager.this.skyRush.getTeamGolemLocationMap().get(Teams.BLUE);
/* 213 */             SkyRush.getPlugin().getTeamGolemMap().put(Teams.BLUE, new GolemaEntity(Teams.BLUE, Teams.BLUE
/* 214 */                   .getName(), golemLocationBlue));
/* 215 */             ((GolemaEntity)SkyRush.getPlugin().getTeamGolemMap().get(Teams.BLUE)).loadArmorstand();
/*     */ 
/*     */             
/* 218 */             SoundUtils.sendSoundForAll(Sound.WITHER_DEATH);
/* 219 */             Bukkit.broadcastMessage("");
/* 220 */             GameMessages.sendHelpMessage(ChatColor.WHITE + "Le " + ChatColor.YELLOW + "SkyRush" + ChatColor.WHITE + " vient de commencer, détruisez les " + ChatColor.YELLOW + "Golems adverses" + ChatColor.WHITE + " et tuer son équipe pour remporter la partie.");
/*     */ 
/*     */             
/* 223 */             (new TitleBuilder(ChatColor.GOLD + "SkyRush", ChatColor.AQUA + "La partie vient de commencer..."))
/* 224 */               .broadcast();
/* 225 */             Bukkit.broadcastMessage(GolemaAPI.getGameSetting().getGamePrefix() + ChatColor.GOLD + "Spawn des Golem, vous devez les protéger...");
/*     */ 
/*     */ 
/*     */             
/* 229 */             for (Teams teams : GolemaAPI.getGameSetting().getTeamManager().getTeamList()) {
/*     */ 
/*     */               
/* 232 */               Location shopLocation = (Location)GameLoaderManager.this.skyRush.getTeamShopLocationMap().get(teams);
/* 233 */               ArmorStand armorStand = (ArmorStand)GameLoaderManager.this.world.spawnEntity(shopLocation, EntityType.ARMOR_STAND);
/* 234 */               armorStand.setCustomName(ChatColor.LIGHT_PURPLE + "" + ChatColor.BOLD + "❂ Shop | Tokens ❂");
/* 235 */               armorStand.setCustomNameVisible(true);
/* 236 */               armorStand.setArms(true);
/* 237 */               armorStand.setGravity(false);
/* 238 */               armorStand.setBasePlate(false);
/*     */ 
/*     */               
/* 241 */               armorStand.setHelmet(CustomSkull.getCustomSkull(TextureHeadLink.SKYRUSH_SHOP.getLink()));
/* 242 */               armorStand.setChestplate(
/* 243 */                   ItemFactory.buildLeatherColorArmor(Material.LEATHER_CHESTPLATE, Color.FUCHSIA));
/* 244 */               armorStand
/* 245 */                 .setLeggings(ItemFactory.buildLeatherColorArmor(Material.LEATHER_LEGGINGS, Color.FUCHSIA));
/* 246 */               armorStand.setBoots(ItemFactory.buildLeatherColorArmor(Material.LEATHER_BOOTS, Color.WHITE));
/* 247 */               armorStand.setItemInHand(new ItemStack(Material.GOLD_INGOT));
/*     */             } 
/*     */ 
/*     */             
/* 251 */             for (Location kitsLocation : GameLoaderManager.this.skyRush.getKitsNPCLocationList()) {
/* 252 */               ArmorStand armorStand = (ArmorStand)GameLoaderManager.this.world.spawnEntity(kitsLocation, EntityType.ARMOR_STAND);
/* 253 */               armorStand.setCustomName(ChatColor.GREEN + "" + ChatColor.BOLD + "Kits");
/* 254 */               armorStand.setCustomNameVisible(true);
/* 255 */               armorStand.setArms(true);
/* 256 */               armorStand.setGravity(false);
/* 257 */               armorStand.setBasePlate(false);
/*     */ 
/*     */               
/* 260 */               armorStand.setHelmet(CustomSkull.getCustomSkull(TextureHeadLink.SKYRUSH_SHOP.getLink()));
/* 261 */               armorStand.setChestplate(
/* 262 */                   ItemFactory.buildLeatherColorArmor(Material.LEATHER_CHESTPLATE, Color.ORANGE));
/* 263 */               armorStand.setLeggings(ItemFactory.buildLeatherColorArmor(Material.LEATHER_LEGGINGS, Color.ORANGE));
/* 264 */               armorStand.setBoots(ItemFactory.buildLeatherColorArmor(Material.LEATHER_BOOTS, Color.GRAY));
/* 265 */               armorStand.setItemInHand(new ItemStack(Material.NAME_TAG));
/*     */             } 
/*     */           }
/*     */         }60L);
/*     */   }
/*     */ }


/* Location:              C:\Users\polux\OneDrive\Bureau\MarsMc\plugins\SkyRush.jar!\net\golema\skyrush\manager\GameLoaderManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */