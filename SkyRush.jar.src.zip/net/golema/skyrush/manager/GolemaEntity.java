/*     */ package net.golema.skyrush.manager;
/*     */ 
/*     */ import net.golema.api.games.teams.Teams;
/*     */ import net.golema.skyrush.SkyRush;
/*     */ import net.md_5.bungee.api.ChatColor;
/*     */ import net.minecraft.server.v1_8_R3.Entity;
/*     */ import net.minecraft.server.v1_8_R3.NBTTagCompound;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.craftbukkit.v1_8_R3.entity.CraftEntity;
/*     */ import org.bukkit.entity.ArmorStand;
/*     */ import org.bukkit.entity.EntityType;
/*     */ import org.bukkit.entity.Golem;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GolemaEntity
/*     */ {
/*     */   private Teams teams;
/*     */   private String name;
/*     */   private Location location;
/*     */   private Golem golem;
/*     */   private double health;
/*     */   private ArmorStand armorStandHeal;
/*     */   
/*     */   public GolemaEntity(Teams teams, String name, Location location) {
/*  33 */     this.teams = teams;
/*  34 */     this.name = name;
/*  35 */     this.location = location;
/*  36 */     this.location.getChunk().load();
/*  37 */     this.health = SkyRush.getPlugin().getGolemHealth();
/*     */     
/*  39 */     this.golem = (Golem)location.getWorld().spawnEntity(location, EntityType.IRON_GOLEM);
/*  40 */     this.golem.setMaxHealth(this.health);
/*  41 */     this.golem.setHealth(this.health);
/*     */ 
/*     */     
/*  44 */     Entity nmsEntity = ((CraftEntity)this.golem).getHandle();
/*  45 */     NBTTagCompound tag = nmsEntity.getNBTTag();
/*  46 */     if (tag == null) {
/*  47 */       tag = new NBTTagCompound();
/*     */     }
/*  49 */     nmsEntity.c(tag);
/*  50 */     tag.setInt("NoAI", 1);
/*  51 */     nmsEntity.f(tag);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void loadArmorstand() {
/*  58 */     Location locationAS = new Location(this.location.getWorld(), this.location.getX(), this.location.getY() + 1.0D, this.location.getZ());
/*  59 */     this.armorStandHeal = (ArmorStand)this.location.getWorld().spawnEntity(locationAS, EntityType.ARMOR_STAND);
/*  60 */     this.armorStandHeal.setGravity(false);
/*  61 */     this.armorStandHeal.setBasePlate(false);
/*  62 */     this.armorStandHeal.setVisible(false);
/*  63 */     this.armorStandHeal.setCustomNameVisible(true);
/*  64 */     this.armorStandHeal.setCustomName(ChatColor.DARK_GRAY + "Initialisation...");
/*  65 */     this.armorStandHeal.setCustomNameVisible(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void refreshArmostand() {
/*  72 */     this.armorStandHeal.setCustomName(this.teams.getChatColor() + "" + ChatColor.BOLD + "Golem " + this.teams.getName() + ChatColor.WHITE + "│ " + ChatColor.DARK_RED + "" + ChatColor.BOLD + this.golem
/*  73 */         .getHealth() + " ❤");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeArmorstand() {
/*  80 */     if (this.armorStandHeal != null) {
/*  81 */       this.armorStandHeal.remove();
/*  82 */       this.armorStandHeal = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public Teams getTeams() {
/*  87 */     return this.teams;
/*     */   }
/*     */   
/*     */   public String getName() {
/*  91 */     return this.name;
/*     */   }
/*     */   
/*     */   public Location getLocation() {
/*  95 */     return this.location;
/*     */   }
/*     */   
/*     */   public Golem getGolem() {
/*  99 */     return this.golem;
/*     */   }
/*     */   
/*     */   public double getHealth() {
/* 103 */     return this.health;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDead() {
/* 110 */     return (this.golem.getHealth() <= 0.0D);
/*     */   }
/*     */ }


/* Location:              C:\Users\polux\OneDrive\Bureau\MarsMc\plugins\SkyRush.jar!\net\golema\skyrush\manager\GolemaEntity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */