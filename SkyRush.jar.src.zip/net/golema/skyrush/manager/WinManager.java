/*    */ package net.golema.skyrush.manager;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import net.golema.api.games.GameStatus;
/*    */ import net.golema.api.games.servers.LoadashServerManager;
/*    */ import net.golema.api.games.teams.Teams;
/*    */ import net.golema.api.players.stats.Stats;
/*    */ import net.golema.api.players.stats.games.SkyRushStats;
/*    */ import net.golema.api.utils.GolemaAPI;
/*    */ import net.golema.skyrush.GamePlayer;
/*    */ import net.md_5.bungee.api.ChatColor;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WinManager
/*    */ {
/*    */   public WinManager() {
/* 26 */     if (!GameStatus.isStatus(GameStatus.GAME)) {
/*    */       return;
/*    */     }
/*    */     
/* 30 */     List<Teams> teamsAlive = new ArrayList<>();
/* 31 */     for (Teams teams : GolemaAPI.getGameSetting().getTeamManager().getTeamList()) {
/* 32 */       List<Player> playerInTeams = GolemaAPI.getGameSetting().getTeamManager().getTeamPlayerList(teams);
/* 33 */       if (!playerInTeams.isEmpty() || playerInTeams.size() > 1) {
/* 34 */         teamsAlive.add(teams);
/*    */       }
/*    */     } 
/*    */     
/* 38 */     if (teamsAlive.size() <= 1) {
/* 39 */       Teams teamWinner = teamsAlive.get(0);
/* 40 */       List<Player> playersWinner = GolemaAPI.getGameSetting().getTeamManager().getTeamPlayerList(teamWinner);
/* 41 */       if (teamWinner == null || playersWinner.isEmpty() || playersWinner.size() < 1) {
/* 42 */         Bukkit.broadcastMessage(GolemaAPI.getGameSetting().getGamePrefix() + ChatColor.RED + "Une erreur s'est produite durant la partie...");
/*    */       } else {
/*    */         
/* 45 */         String winnerName = "";
/* 46 */         for (Player winner : playersWinner)
/* 47 */           winnerName = winnerName + winner.getName() + ", "; 
/* 48 */         winnerName = winnerName.substring(0, winnerName.length() - 2);
/* 49 */         Bukkit.broadcastMessage(GolemaAPI.getGameSetting().getGamePrefix() + ChatColor.WHITE + "L'équipe " + teamWinner
/* 50 */             .getChatColor() + ChatColor.BOLD + teamWinner.getName() + ChatColor.WHITE + " vient de gagner la partie.");
/*    */         
/* 52 */         Bukkit.broadcastMessage(ChatColor.GRAY + "Joueurs restants : " + teamWinner.getChatColor() + winnerName + ChatColor.GRAY + ".");
/*    */         
/* 54 */         for (Player winner : playersWinner) {
/* 55 */           winner.sendMessage(GolemaAPI.getGameSetting().getGamePrefix() + ChatColor.LIGHT_PURPLE + "Félicitations, vous avez gagné !");
/*    */           
/* 57 */           GamePlayer winnerGamePlayer = GamePlayer.getPlayer(winner);
/* 58 */           winnerGamePlayer.addCoins(winner, 50.0F, "Victoire");
/* 59 */           winnerGamePlayer.getPlayerStats().addCoinsWin(50.0F);
/* 60 */           winnerGamePlayer.getPlayerStats().addStats(Stats.WINS, 1);
/*    */         } 
/*    */       } 
/*    */ 
/*    */       
/* 65 */       Bukkit.getOnlinePlayers().forEach(players -> {
/*    */             if (GamePlayer.getPlayer(players) != null && !GamePlayer.getPlayer(players).isSpectator()) {
/*    */               SkyRushStats.updateSkyRushStatsAccount(GamePlayer.getPlayer(players).getPlayerStats(), players.getUniqueId());
/*    */             }
/*    */           });
/*    */       
/* 71 */       LoadashServerManager.manageGameEndReboot(10, "stop");
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\polux\OneDrive\Bureau\MarsMc\plugins\SkyRush.jar!\net\golema\skyrush\manager\WinManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */