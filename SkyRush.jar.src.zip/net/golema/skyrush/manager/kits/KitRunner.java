/*    */ package net.golema.skyrush.manager.kits;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import net.golema.api.games.kits.KitAbstract;
/*    */ import net.golema.api.games.kits.KitsInfos;
/*    */ import net.golema.api.games.teams.Teams;
/*    */ import net.golema.api.utils.builders.items.ItemFactory;
/*    */ import net.golema.skyrush.GamePlayer;
/*    */ import net.md_5.bungee.api.ChatColor;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ import org.bukkit.inventory.meta.ItemMeta;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class KitRunner
/*    */   extends KitAbstract
/*    */ {
/*    */   public KitRunner() {
/* 24 */     register(this);
/*    */   }
/*    */ 
/*    */   
/*    */   public ItemStack getItemIcon(Player player) {
/* 29 */     ItemStack itemStack = new ItemStack(getKitsInfo().getIconItem());
/* 30 */     ItemMeta itemMeta = itemStack.getItemMeta();
/* 31 */     itemMeta.setDisplayName(ChatColor.YELLOW + getKitsInfo().getName());
/* 32 */     List<String> lores = new ArrayList<>();
/* 33 */     lores.add("");
/* 34 */     lores.add(ChatColor.GRAY + "Description:");
/* 35 */     for (String kitLore : getKitsInfo().getDescription())
/* 36 */       lores.add(ChatColor.WHITE + kitLore); 
/* 37 */     lores.add("");
/* 38 */     lores.add(ChatColor.GRAY + "Contenu :");
/* 39 */     lores.add(ChatColor.GRAY + "● " + ChatColor.WHITE + "1 Armure en cuir");
/* 40 */     lores.add(ChatColor.GRAY + "● " + ChatColor.WHITE + "1 Epée en pierre");
/* 41 */     lores.add(ChatColor.GRAY + "● " + ChatColor.WHITE + "1 Pioche en fer");
/* 42 */     lores.add(ChatColor.GRAY + "● " + ChatColor.WHITE + "148 Blocs");
/* 43 */     lores.add(ChatColor.GRAY + "● " + ChatColor.WHITE + "8 Steaks de Mouton");
/* 44 */     lores.add(ChatColor.GRAY + "● " + ChatColor.WHITE + "1 Potion de Speed");
/* 45 */     lores.add("");
/* 46 */     lores.add(ChatColor.GOLD + "» " + ChatColor.YELLOW + "Cliquez pour utiliser");
/* 47 */     itemMeta.setLore(lores);
/* 48 */     itemStack.setItemMeta(itemMeta);
/* 49 */     return itemStack;
/*    */   }
/*    */ 
/*    */   
/*    */   public KitsInfos getKitsInfo() {
/* 54 */     return KitsInfos.SKYRUSH_RUNNER;
/*    */   }
/*    */ 
/*    */   
/*    */   public void sendKit(Player player) {
/* 59 */     GamePlayer gamePlayer = GamePlayer.getPlayer(player);
/* 60 */     player.getInventory().addItem(new ItemStack[] { (new ItemFactory(Material.STONE_SWORD)).done() });
/* 61 */     player.getInventory().addItem(new ItemStack[] { (new ItemFactory(Material.IRON_PICKAXE)).done() });
/* 62 */     player.getInventory().addItem(new ItemStack[] { (new ItemFactory(new ItemStack(Material.STAINED_CLAY, 1, 
/* 63 */               gamePlayer.getTeam().equals(Teams.RED) ? 14 : 3))).withAmount(148).done() });
/* 64 */     player.getInventory().addItem(new ItemStack[] { (new ItemFactory(Material.COOKED_MUTTON)).withAmount(8).done() });
/* 65 */     player.getInventory().addItem(new ItemStack[] { (new ItemFactory(new ItemStack(Material.POTION, 1, (short)16386))).done() });
/*    */   }
/*    */ }


/* Location:              C:\Users\polux\OneDrive\Bureau\MarsMc\plugins\SkyRush.jar!\net\golema\skyrush\manager\kits\KitRunner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */