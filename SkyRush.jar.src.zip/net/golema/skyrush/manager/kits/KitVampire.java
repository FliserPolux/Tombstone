/*    */ package net.golema.skyrush.manager.kits;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import net.golema.api.games.kits.KitAbstract;
/*    */ import net.golema.api.games.kits.KitsInfos;
/*    */ import net.golema.api.games.teams.Teams;
/*    */ import net.golema.api.utils.builders.items.ItemFactory;
/*    */ import net.golema.skyrush.GamePlayer;
/*    */ import net.md_5.bungee.api.ChatColor;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ import org.bukkit.inventory.meta.ItemMeta;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class KitVampire
/*    */   extends KitAbstract
/*    */ {
/*    */   public KitVampire() {
/* 24 */     register(this);
/*    */   }
/*    */ 
/*    */   
/*    */   public ItemStack getItemIcon(Player player) {
/* 29 */     ItemStack itemStack = new ItemStack(getKitsInfo().getIconItem());
/* 30 */     ItemMeta itemMeta = itemStack.getItemMeta();
/* 31 */     itemMeta.setDisplayName(ChatColor.YELLOW + getKitsInfo().getName());
/* 32 */     List<String> lores = new ArrayList<>();
/* 33 */     lores.add("");
/* 34 */     lores.add(ChatColor.GRAY + "Description:");
/* 35 */     for (String kitLore : getKitsInfo().getDescription())
/* 36 */       lores.add(ChatColor.WHITE + kitLore); 
/* 37 */     lores.add("");
/* 38 */     lores.add(ChatColor.GRAY + "Contenu :");
/* 39 */     lores.add(ChatColor.GRAY + "● " + ChatColor.WHITE + "1 Armure en cuir");
/* 40 */     lores.add(ChatColor.GRAY + "● " + ChatColor.WHITE + "1 Epée en pierre");
/* 41 */     lores.add(ChatColor.GRAY + "● " + ChatColor.WHITE + "1 Pioche en fer");
/* 42 */     lores.add(ChatColor.GRAY + "● " + ChatColor.WHITE + "128 Blocs");
/* 43 */     lores.add("");
/* 44 */     lores.add(ChatColor.GOLD + "» " + ChatColor.YELLOW + "Cliquez pour utiliser");
/* 45 */     itemMeta.setLore(lores);
/* 46 */     itemStack.setItemMeta(itemMeta);
/* 47 */     return itemStack;
/*    */   }
/*    */ 
/*    */   
/*    */   public KitsInfos getKitsInfo() {
/* 52 */     return KitsInfos.SKYRUSH_VAMPIRE;
/*    */   }
/*    */ 
/*    */   
/*    */   public void sendKit(Player player) {
/* 57 */     GamePlayer gamePlayer = GamePlayer.getPlayer(player);
/* 58 */     player.getInventory().addItem(new ItemStack[] { (new ItemFactory(Material.STONE_SWORD)).done() });
/* 59 */     player.getInventory().addItem(new ItemStack[] { (new ItemFactory(Material.IRON_PICKAXE)).done() });
/* 60 */     player.getInventory().addItem(new ItemStack[] { (new ItemFactory(new ItemStack(Material.STAINED_CLAY, 1, 
/* 61 */               gamePlayer.getTeam().equals(Teams.RED) ? 14 : 3))).withAmount(128).done() });
/*    */   }
/*    */ }


/* Location:              C:\Users\polux\OneDrive\Bureau\MarsMc\plugins\SkyRush.jar!\net\golema\skyrush\manager\kits\KitVampire.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */