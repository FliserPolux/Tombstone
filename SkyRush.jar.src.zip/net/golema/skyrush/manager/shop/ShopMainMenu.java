/*     */ package net.golema.skyrush.manager.shop;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import net.golema.api.utils.builders.inventories.InventoryBuilder;
/*     */ import net.golema.api.utils.builders.items.ItemFactory;
/*     */ import net.golema.skyrush.GamePlayer;
/*     */ import net.golema.skyrush.SkyRush;
/*     */ import net.md_5.bungee.api.ChatColor;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.inventory.InventoryClickEvent;
/*     */ import org.bukkit.event.inventory.InventoryCloseEvent;
/*     */ import org.bukkit.event.inventory.InventoryType;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ 
/*     */ public class ShopMainMenu
/*     */   implements Listener
/*     */ {
/*  25 */   public Map<Player, Inventory> menuInventoryMap = new HashMap<>();
/*     */   
/*  27 */   private String inventoryName = "Shop - Tokens";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ShopMainMenu(Player player) {
/*  35 */     this.menuInventoryMap.remove(player);
/*  36 */     Bukkit.getPluginManager().registerEvents(this, (Plugin)SkyRush.getPlugin());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  76 */     Inventory inventory = (new InventoryBuilder(this.inventoryName)).addLine(new String[] { "x", "x", "", "", "", "", "", "x", "x" }).addLine(new String[] { "x", "", "chainmail_helmet", "iron_sword", "", "sandstone_blocks", "enderpearl", "", "x" }).addLine(new String[] { "", "", "iron_chestplate", "diamond_sword", "", "fishing_rod", "potion_heal", "", "" }).addLine(new String[] { "", "", "chainmail_leggings", "arrow", "", "", "", "", "" }).addLine(new String[] { "x", "", "iron_boots", "bow", "", "obsidian_bloc", "diamond_pickaxe", "", "x" }).addLine(new String[] { "x", "x", "", "", "", "", "", "x", "x" }).setItem("x", (new ItemFactory(new ItemStack(Material.STAINED_GLASS_PANE, 1, (short)5))).withName("§0").done()).setItem("chainmail_helmet", buildItemShop(Material.CHAINMAIL_HELMET, "Casque en maille", 20, 1)).setItem("iron_chestplate", buildItemShop(Material.IRON_CHESTPLATE, "Plastron en fer", 70, 1)).setItem("chainmail_leggings", buildItemShop(Material.CHAINMAIL_LEGGINGS, "Pantalon en maille", 30, 1)).setItem("iron_boots", buildItemShop(Material.IRON_BOOTS, "Bottes en fer", 10, 1)).setItem("iron_sword", buildItemShop(Material.IRON_SWORD, "Epée en fer", 30, 1)).setItem("diamond_sword", buildItemShop(Material.DIAMOND_SWORD, "Epée en diamant", 50, 1)).setItem("arrow", buildItemShop(Material.ARROW, "Flêches", 30, 6)).setItem("bow", buildItemShop(Material.BOW, "Arc", 30, 1)).setItem("obsidian_bloc", buildItemShop(Material.OBSIDIAN, "Obsidienne", 35, 2)).setItem("diamond_pickaxe", buildItemShop(Material.DIAMOND_PICKAXE, "Pioche en diamant", 10, 1)).setItem("sandstone_blocks", buildItemShop(Material.SANDSTONE, "Sandstone", 10, 64)).setItem("enderpearl", buildItemShop(Material.ENDER_PEARL, "Enderpearl", 100, 1)).setItem("fishing_rod", buildItemShop(Material.FISHING_ROD, "Cânne à pêche", 100, 1)).setItem("potion_heal", buildItemShopWithData(Material.POTION, "Potion de soin", 60, 1, (short)16453)).build(player);
/*     */     
/*  78 */     this.menuInventoryMap.put(player, inventory);
/*  79 */     player.openInventory(inventory);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onInventoryClick(InventoryClickEvent event) {
/*  84 */     Player player = (Player)event.getWhoClicked();
/*  85 */     GamePlayer gamePlayer = GamePlayer.getPlayer(player);
/*  86 */     if (event.getInventory() == null)
/*     */       return; 
/*  88 */     if (gamePlayer == null || gamePlayer.isSpectator())
/*     */       return; 
/*  90 */     if (event.getCurrentItem() == null)
/*     */       return; 
/*  92 */     if (event.getCurrentItem().getType().equals(Material.AIR))
/*     */       return; 
/*  94 */     if (!event.getInventory().getName().equalsIgnoreCase(this.inventoryName))
/*     */       return; 
/*  96 */     if (!event.getInventory().equals(this.menuInventoryMap.get(player)))
/*     */       return; 
/*  98 */     if (event.getClickedInventory().getType().equals(InventoryType.PLAYER))
/*     */       return; 
/* 100 */     event.setCancelled(true);
/* 101 */     switch (event.getCurrentItem().getType()) {
/*     */ 
/*     */       
/*     */       case CHAINMAIL_HELMET:
/* 105 */         gamePlayer
/* 106 */           .makeTrade(20, (new ItemFactory(event
/* 107 */               .getCurrentItem().getType()))
/* 108 */             .withAmount(event.getCurrentItem().getAmount()).done(), event
/* 109 */             .getCurrentItem().getItemMeta().getDisplayName());
/*     */         break;
/*     */       case IRON_CHESTPLATE:
/* 112 */         gamePlayer
/* 113 */           .makeTrade(70, (new ItemFactory(event
/* 114 */               .getCurrentItem().getType()))
/* 115 */             .withAmount(event.getCurrentItem().getAmount()).done(), event
/* 116 */             .getCurrentItem().getItemMeta().getDisplayName());
/*     */         break;
/*     */       case CHAINMAIL_LEGGINGS:
/* 119 */         gamePlayer
/* 120 */           .makeTrade(30, (new ItemFactory(event
/* 121 */               .getCurrentItem().getType()))
/* 122 */             .withAmount(event.getCurrentItem().getAmount()).done(), event
/* 123 */             .getCurrentItem().getItemMeta().getDisplayName());
/*     */         break;
/*     */       case IRON_BOOTS:
/* 126 */         gamePlayer
/* 127 */           .makeTrade(10, (new ItemFactory(event
/* 128 */               .getCurrentItem().getType()))
/* 129 */             .withAmount(event.getCurrentItem().getAmount()).done(), event
/* 130 */             .getCurrentItem().getItemMeta().getDisplayName());
/*     */         break;
/*     */ 
/*     */       
/*     */       case IRON_SWORD:
/* 135 */         gamePlayer
/* 136 */           .makeTrade(30, (new ItemFactory(event
/* 137 */               .getCurrentItem().getType()))
/* 138 */             .withAmount(event.getCurrentItem().getAmount()).done(), event
/* 139 */             .getCurrentItem().getItemMeta().getDisplayName());
/*     */         break;
/*     */       case DIAMOND_SWORD:
/* 142 */         gamePlayer
/* 143 */           .makeTrade(50, (new ItemFactory(event
/* 144 */               .getCurrentItem().getType()))
/* 145 */             .withAmount(event.getCurrentItem().getAmount()).done(), event
/* 146 */             .getCurrentItem().getItemMeta().getDisplayName());
/*     */         break;
/*     */       case ARROW:
/* 149 */         gamePlayer
/* 150 */           .makeTrade(30, (new ItemFactory(event
/* 151 */               .getCurrentItem().getType()))
/* 152 */             .withAmount(event.getCurrentItem().getAmount()).done(), event
/* 153 */             .getCurrentItem().getItemMeta().getDisplayName());
/*     */         break;
/*     */       case BOW:
/* 156 */         gamePlayer
/* 157 */           .makeTrade(40, (new ItemFactory(event
/* 158 */               .getCurrentItem().getType()))
/* 159 */             .withAmount(event.getCurrentItem().getAmount()).done(), event
/* 160 */             .getCurrentItem().getItemMeta().getDisplayName());
/*     */         break;
/*     */ 
/*     */       
/*     */       case OBSIDIAN:
/* 165 */         gamePlayer
/* 166 */           .makeTrade(30, (new ItemFactory(event
/* 167 */               .getCurrentItem().getType()))
/* 168 */             .withAmount(event.getCurrentItem().getAmount()).done(), event
/* 169 */             .getCurrentItem().getItemMeta().getDisplayName());
/*     */         break;
/*     */       case DIAMOND_PICKAXE:
/* 172 */         gamePlayer
/* 173 */           .makeTrade(10, (new ItemFactory(event
/* 174 */               .getCurrentItem().getType()))
/* 175 */             .withAmount(event.getCurrentItem().getAmount()).done(), event
/* 176 */             .getCurrentItem().getItemMeta().getDisplayName());
/*     */         break;
/*     */ 
/*     */       
/*     */       case SANDSTONE:
/* 181 */         gamePlayer
/* 182 */           .makeTrade(10, (new ItemFactory(event
/* 183 */               .getCurrentItem().getType()))
/* 184 */             .withAmount(event.getCurrentItem().getAmount()).done(), event
/* 185 */             .getCurrentItem().getItemMeta().getDisplayName());
/*     */         break;
/*     */       case ENDER_PEARL:
/* 188 */         gamePlayer.makeTrade(100, (new ItemFactory(event
/* 189 */               .getCurrentItem().getType()))
/* 190 */             .withAmount(event.getCurrentItem().getAmount()).done(), event
/* 191 */             .getCurrentItem().getItemMeta().getDisplayName());
/*     */         break;
/*     */       case FISHING_ROD:
/* 194 */         gamePlayer.makeTrade(100, (new ItemFactory(event
/* 195 */               .getCurrentItem().getType()))
/* 196 */             .withAmount(event.getCurrentItem().getAmount()).done(), event
/* 197 */             .getCurrentItem().getItemMeta().getDisplayName());
/*     */         break;
/*     */       case POTION:
/* 200 */         gamePlayer.makeTrade(60, (new ItemFactory(new ItemStack(event
/*     */                 
/* 202 */                 .getCurrentItem().getType(), 1, event.getCurrentItem().getDurability())))
/* 203 */             .withAmount(event.getCurrentItem().getAmount()).done(), event
/* 204 */             .getCurrentItem().getItemMeta().getDisplayName());
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @EventHandler
/*     */   public void onInventoryClose(InventoryCloseEvent event) {
/* 213 */     Player player = (Player)event.getPlayer();
/* 214 */     if (event.getInventory() == null)
/*     */       return; 
/* 216 */     if (this.menuInventoryMap.get(player) == null)
/*     */       return; 
/* 218 */     if (((Inventory)this.menuInventoryMap.get(player)).equals(event.getInventory())) {
/* 219 */       this.menuInventoryMap.remove(player);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ItemStack buildItemShop(Material material, String name, int price, int amount) {
/* 231 */     return (new ItemFactory(material)).withName(ChatColor.WHITE + "" + ChatColor.UNDERLINE + name).withAmount(amount)
/* 232 */       .withLore(new String[] {
/*     */           
/*     */           "", ChatColor.GRAY + "Quantité : " + ChatColor.LIGHT_PURPLE + amount, ChatColor.GRAY + "Prix : " + ChatColor.YELLOW + "" + ChatColor.BOLD + price + " ✸", "", ChatColor.DARK_GREEN + "" + ChatColor.BOLD + "» " + ChatColor.GREEN + "Cliquez pour acheter"
/* 235 */         }).done();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ItemStack buildItemShopWithData(Material material, String name, int price, int amount, short data) {
/* 249 */     return (new ItemFactory(new ItemStack(material, 1, data)))
/* 250 */       .withName(ChatColor.WHITE + "" + ChatColor.UNDERLINE + name).withAmount(amount)
/* 251 */       .withLore(new String[] {
/*     */           
/*     */           "", ChatColor.GRAY + "Quantité : " + ChatColor.LIGHT_PURPLE + amount, ChatColor.GRAY + "Prix : " + ChatColor.YELLOW + "" + ChatColor.BOLD + price + " ✸", "", ChatColor.DARK_GREEN + "" + ChatColor.BOLD + "» " + ChatColor.GREEN + "Cliquez pour acheter"
/* 254 */         }).done();
/*     */   }
/*     */ }


/* Location:              C:\Users\polux\OneDrive\Bureau\MarsMc\plugins\SkyRush.jar!\net\golema\skyrush\manager\shop\ShopMainMenu.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */