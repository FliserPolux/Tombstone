/*     */ package net.golema.skyrush.runnables;
/*     */ 
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.Random;
/*     */ import net.golema.api.games.GameLobbyTask;
/*     */ import net.golema.api.games.GameStatus;
/*     */ import net.golema.api.games.teams.Teams;
/*     */ import net.golema.api.utils.GolemaAPI;
/*     */ import net.golema.skyrush.GamePlayer;
/*     */ import net.golema.skyrush.SkyRush;
/*     */ import net.golema.skyrush.manager.GolemaEntity;
/*     */ import net.md_5.bungee.api.ChatColor;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.scheduler.BukkitRunnable;
/*     */ 
/*     */ public class ScoreboardRunnable
/*     */   extends BukkitRunnable
/*     */ {
/*  21 */   private int gameTime = 0;
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/*  26 */     for (Player playerOnline : Bukkit.getOnlinePlayers()) {
/*  27 */       GamePlayer gamePlayer = GamePlayer.getPlayer(playerOnline);
/*  28 */       switch (GameStatus.getStatus()) {
/*     */         case LOBBY:
/*  30 */           gamePlayer.scoreboardSign.setLine(10, ChatColor.WHITE + "Joueurs : " + ChatColor.YELLOW + 
/*  31 */               Bukkit.getOnlinePlayers().size() + ChatColor.GRAY + "/" + ChatColor.YELLOW + 
/*  32 */               Bukkit.getMaxPlayers());
/*  33 */           gamePlayer.scoreboardSign.setLine(5, ChatColor.WHITE + "Lancement : " + ChatColor.GREEN + (new SimpleDateFormat("mm:ss"))
/*  34 */               .format(new Date((GameLobbyTask.lobbyTimer.intValue() * 1000))));
/*  35 */           gamePlayer.scoreboardSign.setLine(3, ChatColor.WHITE + "Kit : " + ChatColor.LIGHT_PURPLE + 
/*  36 */               GolemaAPI.getGameSetting().getKitManager().getPlayerKitName(playerOnline.getUniqueId()));
/*     */ 
/*     */ 
/*     */         
/*     */         case GAME:
/*  41 */           gamePlayer.scoreboardSign.setObjectiveName(ChatColor.GOLD + "" + ChatColor.BOLD + 
/*  42 */               GolemaAPI.getGameSetting().getGameName() + ChatColor.WHITE + "│ " + ChatColor.GRAY + (new SimpleDateFormat("mm:ss"))
/*  43 */               .format(new Date((this.gameTime * 1000))));
/*     */ 
/*     */           
/*  46 */           gamePlayer.scoreboardSign.setLine(11, ChatColor.WHITE + "Tués : " + ChatColor.GREEN + gamePlayer
/*  47 */               .getKills());
/*  48 */           gamePlayer.scoreboardSign.setLine(10, ChatColor.WHITE + "Mort : " + ChatColor.RED + gamePlayer
/*  49 */               .getDeaths());
/*  50 */           gamePlayer.scoreboardSign.setLine(8, ChatColor.WHITE + "Tokens : " + ChatColor.YELLOW + "" + ChatColor.BOLD + gamePlayer
/*  51 */               .getTokens() + " ✸");
/*     */ 
/*     */           
/*  54 */           if (SkyRush.getPlugin().getTeamGolemMap().get(Teams.RED) != null && 
/*  55 */             SkyRush.getPlugin().getTeamGolemMap().get(Teams.BLUE) != null) {
/*     */             
/*  57 */             if (((GolemaEntity)SkyRush.getPlugin().getTeamGolemMap().get(Teams.RED)).getGolem() == null || (
/*  58 */               (GolemaEntity)SkyRush.getPlugin().getTeamGolemMap().get(Teams.RED)).isDead()) {
/*     */               
/*  60 */               int playerStay = GolemaAPI.getGameSetting().getTeamManager().getTeamPlayerList(Teams.RED).size();
/*  61 */               gamePlayer.scoreboardSign.setLine(6, Teams.RED
/*  62 */                   .getChatColor() + "■ " + ChatColor.WHITE + (
/*  63 */                   (playerStay == 1) ? "Joueur" : "Joueurs") + " : " + Teams.RED.getChatColor() + playerStay + " ⚑");
/*     */               
/*  65 */               ((GolemaEntity)SkyRush.getPlugin().getTeamGolemMap().get(Teams.RED)).removeArmorstand();
/*     */             } else {
/*     */               
/*  68 */               double golemHealth = ((GolemaEntity)SkyRush.getPlugin().getTeamGolemMap().get(Teams.RED)).getGolem().getHealth();
/*  69 */               gamePlayer.scoreboardSign.setLine(6, Teams.RED.getChatColor() + "■ " + ChatColor.WHITE + "Golem : " + Teams.RED
/*  70 */                   .getChatColor() + (int)golemHealth + " ❤");
/*  71 */               ((GolemaEntity)SkyRush.getPlugin().getTeamGolemMap().get(Teams.RED)).refreshArmostand();
/*     */             } 
/*     */             
/*  74 */             if (((GolemaEntity)SkyRush.getPlugin().getTeamGolemMap().get(Teams.BLUE)).getGolem() == null || (
/*  75 */               (GolemaEntity)SkyRush.getPlugin().getTeamGolemMap().get(Teams.BLUE)).isDead()) {
/*     */               
/*  77 */               int playerStay = GolemaAPI.getGameSetting().getTeamManager().getTeamPlayerList(Teams.BLUE).size();
/*  78 */               gamePlayer.scoreboardSign.setLine(5, Teams.BLUE
/*  79 */                   .getChatColor() + "■ " + ChatColor.WHITE + (
/*  80 */                   (playerStay == 1) ? "Joueur" : "Joueurs") + " : " + Teams.BLUE.getChatColor() + playerStay + " ⚑");
/*     */               
/*  82 */               ((GolemaEntity)SkyRush.getPlugin().getTeamGolemMap().get(Teams.BLUE)).removeArmorstand();
/*     */             } else {
/*     */               
/*  85 */               double golemHealth = ((GolemaEntity)SkyRush.getPlugin().getTeamGolemMap().get(Teams.BLUE)).getGolem().getHealth();
/*  86 */               gamePlayer.scoreboardSign.setLine(5, Teams.BLUE.getChatColor() + "■ " + ChatColor.WHITE + "Golem : " + Teams.BLUE
/*  87 */                   .getChatColor() + (int)golemHealth + " ❤");
/*  88 */               ((GolemaEntity)SkyRush.getPlugin().getTeamGolemMap().get(Teams.BLUE)).refreshArmostand();
/*     */             } 
/*     */           } 
/*     */ 
/*     */           
/*  93 */           if (!gamePlayer.isSpectator() && (
/*  94 */             new Random()).nextBoolean()) {
/*  95 */             gamePlayer.addTokens((new Random()).nextInt(2) + 1, false);
/*     */           }
/*     */       } 
/*     */ 
/*     */ 
/*     */     
/*     */     } 
/* 102 */     if (GameStatus.getStatus().equals(GameStatus.GAME)) {
/* 103 */       this.gameTime++;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getGameTime() {
/* 110 */     return this.gameTime;
/*     */   }
/*     */ }


/* Location:              C:\Users\polux\OneDrive\Bureau\MarsMc\plugins\SkyRush.jar!\net\golema\skyrush\runnables\ScoreboardRunnable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */